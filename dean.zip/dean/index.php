<?php
    define('BASE_ROOT', getcwd());
    include BASE_ROOT . '/assets/php/core.php';
    include BASE_ROOT . '/assets/php/user.php';
    include BASE_ROOT . '/assets/php/image.php';
    include BASE_ROOT . '/assets/php/data.php';
    include BASE_ROOT . '/assets/php/page.php';
    define("BASE_PATH", baseURL());
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title><?php print $CONTENT['title'] . " | " . WEBNAME ?></title>
    <link rel="shortcut icon" href="<?php echo BASE_PATH ?>/assets/img/lspu.png">
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH ?>assets/css/fullcalendar.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH ?>assets/css/styles.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo BASE_PATH ?>assets/fancybox/jquery.fancybox-1.3.4.css" />
    <script src="<?php echo BASE_PATH ?>assets/js/jquery.min.js"></script>
    <script src="<?php echo BASE_PATH ?>assets/fancybox/jquery.easing-1.3.pack.js"></script>
    <script src="<?php echo BASE_PATH ?>assets/fancybox/jquery.fancybox-1.3.4.pack.js"></script>
    <script src="<?php echo BASE_PATH ?>assets/js/fullcalendar.js"></script>
    <script src="<?php echo BASE_PATH ?>assets/js/custom.js"></script>
</head>
<body>
    <?php print getContents("header") ?>
    <?php print $CONTENT['content'] ?>
</body>
</html>

