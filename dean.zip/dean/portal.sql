-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 10, 2015 at 11:16 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `portal`
--

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL,
  `edate` date NOT NULL,
  `name` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `sdate`, `edate`, `name`) VALUES
(7, '2015-02-14', '2015-02-14', 'Valentine''s Day'),
(9, '2015-06-19', '2015-06-19', 'Rizal''s Day'),
(10, '2015-08-10', '2015-08-13', 'Thesis Modification Week'),
(11, '2015-07-27', '2015-07-27', 'SONA'),
(12, '2015-08-01', '2015-08-01', 'Thesis Defense');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `message`) VALUES
(1, '<p><strong><span style=\\"color: #993300; font-size: 10pt;\\">Mrs. Mia V. Villarica</span><br /></strong></p>\r\n<p>Associate Dean, College of Computer Studies</p>\r\n<p>&nbsp;</p>\r\n<p dir=\\"\\\\\\"><span style=\\"font-size: 8pt;\\"><strong>TO ALL STUDENTS WHO WILL HAVE THEIR DEFENSE, GOODLUCK! HOPE YOU ALL PASS. MAY GOD GUIDE AND BLESS YOU!</strong></span></p>'),
(2, '<p style=\\"text-align: right;\\"><span style=\\"color: #993300;\\"><strong><span style=\\"font-size: 10pt;\\"><span style=\\"color: #333333; font-size: 8pt;\\">2015-08-09 2:18:34 PM</span><span style=\\"color: #000000;\\"><br /></span></span></strong></span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\\"color: #993300;\\"><strong><span style=\\"font-size: 10pt;\\">ALL BSCS / BSIT 1st Year:</span></strong></span></p>\r\n<p><span style=\\"font-size: 10pt; color: #000000;\\">Rock en Roll to the World!</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\\"color: #993300;\\"><strong><span style=\\"font-size: 10pt;\\">ALL BSCS / BSIT 2nd Year:</span></strong></span></p>\r\n<p><span style=\\"font-size: 10pt; color: #000000;\\">Rock en Roll to the World!</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\\"color: #993300;\\"><strong><span style=\\"font-size: 10pt;\\">ALL STUDENTS:</span></strong></span></p>\r\n<p><span style=\\"font-size: 10pt; color: #000000;\\">Rock en Roll to the World!</span></p>');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `stamp` datetime NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `status` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `uid`, `stamp`, `title`, `content`, `status`) VALUES
(1, 12, '2015-08-09 00:30:34', 'Welcome students!', '<p>Rock en Roll to the world! Alright!</p>', 1),
(2, 13, '2015-08-09 00:53:13', 'Attention : Concerned Graduating Students last Summer 2015', '<p>Huwag kayong pabebe!</p>', 1);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `lname` varchar(20) NOT NULL,
  `fname` varchar(20) NOT NULL,
  `mname` varchar(20) NOT NULL,
  `bdate` date NOT NULL,
  `email` varchar(50) NOT NULL,
  `bsdeg` varchar(200) NOT NULL,
  `msdeg` varchar(200) NOT NULL,
  `drdeg` varchar(200) NOT NULL,
  `teach` text NOT NULL,
  `address` varchar(255) NOT NULL,
  `bplace` varchar(255) NOT NULL,
  `specialization` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `uid`, `image`, `lname`, `fname`, `mname`, `bdate`, `email`, `bsdeg`, `msdeg`, `drdeg`, `teach`, `address`, `bplace`, `specialization`, `qualification`) VALUES
(1, 12, '71121027_15845403.jpg', 'Amores', 'Jennifer', 'Garrido', '1980-05-26', 'uc.jamores@gmail.com', 'BSCS', 'MSCS', '', 'Data Structures,Software Engineering,Systems Analysis and Design', 'Brgy. San Juan, Kalayaan, Laguna', 'Brgy. San Juan, Kalayaan, Laguna', 'Programming', 'VB.net'),
(2, 13, '35970805_94965052.jpg', 'Bermudez', 'Leo', 'Capua', '1970-02-14', 'uclbermudez@gmail.com', 'BSCS', 'MSCS', '', 'Data Structures,Software Engineering,Systems Analysis and Design', 'Bagumbayan, Sta. Cruz', 'Bagumbayan, Sta. Cruz', 'Programming', 'PHP, Java');

-- --------------------------------------------------------

--
-- Table structure for table `salt`
--

CREATE TABLE IF NOT EXISTS `salt` (
  `id` int(11) NOT NULL,
  `prefix` text NOT NULL,
  `suffix` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `salt`
--

INSERT INTO `salt` (`id`, `prefix`, `suffix`) VALUES
(1, 'VxhcyFnWE0', 'K3sinVE01t'),
(12, 'vgtkTliu5L', 'TCFBZxNLOz'),
(13, '3dcDLGFSNt', 'qblMQ5Thtk');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE IF NOT EXISTS `upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `file` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `public` smallint(1) NOT NULL,
  `publish` smallint(1) NOT NULL,
  `review` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`id`, `uid`, `file`, `title`, `description`, `stamp`, `public`, `publish`, `review`) VALUES
(2, 13, '92963325_49819380.pptx', 'Presentation', 'Presentation', '2015-08-09 14:56:04', 1, 1, 'nice presentation!'),
(3, 13, '45417691_68734251.pdf', 'PDF', 'PDF', '2015-08-08 16:59:24', 1, 1, ''),
(4, 13, '34836756_55072925.docx', 'Word File', 'Word File', '2015-08-08 16:59:24', 1, 1, ''),
(5, 13, '20339399_53371853.xlsx', 'Excel', 'Excel', '2015-08-09 15:14:17', 1, 1, 'rock en roll to the world!-=-alright!-=-wag kang pabebe!-=-ok na to'),
(13, 12, '61531726_34654781.pdf, 31186703_56908501.pptx, 28987177_57515085.docx', 'Assorted Files', 'Assorted Files', '2015-08-10 07:54:40', 1, 1, 'kulang ng photo-=-zip file to, nice!'),
(16, 12, '98491151_69019082.pdf', 'PDF', 'PDF', '2015-08-09 17:00:55', 1, 0, ''),
(17, 12, '88820093_88369111.pdf', 'fdf', 'grrtr', '2015-08-10 07:37:01', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `sque` int(11) NOT NULL,
  `sans` text NOT NULL,
  `code` varchar(20) NOT NULL,
  `type` smallint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user`, `pass`, `sque`, `sans`, `code`, `type`) VALUES
(1, 'deanportal', 'd830cdd10572637a3794811f02fb6aea114ab5f6', 2, 'bart', 'deanportal', 1),
(12, 'professor1', 'ef091401868909ecf13dcd454c3f5fd85eb125f2', 0, '', '', 0),
(13, 'professor2', 'bf5224cc82651353454fc2d75245ccbaa479e00c', 0, '', '', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
