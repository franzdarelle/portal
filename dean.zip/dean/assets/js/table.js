$(document).ready(function(){
	$('input[name=checkall]').click(function(){
		var check_status = this.checked;
		var checkbox_id  = $(this).attr('input-class');
		$('input.'+checkbox_id).each(function(){
			this.checked = check_status;
			check_status? $(this).parents('tr').addClass('selected') : $(this).parents('tr').removeClass('selected');
		});
	});
	$('.tableoptions').css({"padding":"0px 0px 10px"});
	$('.tableactions').css({"width":80});
	$('.checkAll').css({"width":5,"padding":"10px 0","text-align":"center"});
	$('#example').DataTable({
	    aoColumnDefs: [{
	        bSortable: false,
	        aTargets: [ 0 ]
	    }],
	    aaSorting: []
	});
	$('tbody input[type=checkbox]').click(function(){
		$(this).is(':checked')? $(this).parents('tr').addClass('selected') : $(this).parents('tr').removeClass('selected');
	});
	$('.addbutton').click(function(){
		$(location).attr("href", $(this).attr("location"));
	});
	$('.editbutton').click(function(){
		var items = new Array;
	    $("input."+$(this).attr('input-class')).each(function(){
			checked = this.checked? true : false;
			if(checked) {
				items.push($(this).attr("value"));
			}
	    });
	    if(items.length==1) {
	    	$(location).attr("href", $(this).attr("location") + "/" +items[0]);
	    } else if(items.length>1) {
	    	alert("This operation cannot be performed on more than one item. Select a single item and try again.");
	    } else {
	    	alert("There is no selected item.");
	    }
	});
	$('.deletebutton').click(function(){
		var items = new Array;
		var apath = $(this).attr("ajax-path");
	    $("input."+$(this).attr('input-class')).each(function(){
	    	checked = this.checked? true : false;
	    	if(checked) {
	        	items.push($(this).attr("value"));
	    	}
	    });
	    if(items.length) {
	    	if(confirm("Delete selected " + ((items.length>1)? 'items' : 'item') + '?')) {
		    	$.each(items, function(i,id){
		    		$.ajax({
						url: apath,
						type:"POST",
						data:{id:id}
			       	}).done(function(e){
			       		$("input[value='"+id+"']").parents('tr').fadeOut(function(){
							$(this).remove();
						});
			       	});
		    	});
		    }
	    } else
	    	alert("There are no selected items.");
	});
	$('.publishbutton').click(function(){
		var items = new Array;
		var rpath = $(this).attr("location");
		var alert = $(this).attr("question");
		var apath = $(this).attr("ajax-path");
	    $("input."+$(this).attr('input-class')).each(function(){
	    	checked = this.checked? true : false;
	    	if(checked) {
	        	items.push($(this).attr("value"));
	    	}
	    });

	    if(items.length) {
	    	if(confirm(alert + " selected " + ((items.length>1)? 'items' : 'item') + '?')) {
		    	$.ajax({
					url: apath,
					type:"POST",
					data:{items:items}
		       	}).done(function(e){ 
		       		$(location).attr("href", rpath);
		       	});
		    }
	    } else
	    	alert("There are no selected items.");
	});
})