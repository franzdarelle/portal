function popup_box( options, buttons ){
    var options_defaults = {
        title: "Message",
        content: "Please provide a text...",
        width: false,
        height:false,
        start: false,
        place: false,
        class: "xxx",
        positionTop: 0
    }
    var buttons_defaults = { submit:false, name:false, id:false, class:false, value:false, close:false }
    var options = $.extend(options_defaults, options);
    var buttons = $.extend(buttons_defaults, buttons);
    var buts = '';
    if(buttons.submit){
        buts += "<input type='submit' name='"+buttons.name+"' id='"+buttons.id+"' value='"+buttons.value+"' class='"+buttons.class+"'>";
    }
    if(buttons.close!=false) buts += createButton(buttons.close);
    function createButton(value){
        return "<input type='button' value='"+value+"' class='input-cancel esc"+options.class+"'>";
    }
    var popup_container = $("<div></div>", { class : "uiBSpopupwin"});
    var popup_header= $("<div></div>", { class : "popupwinHeader" });
    var popup_close = $("<div></div>", { id : "fancybox-close" }).attr('title', 'Close').show();
    var popup_title = $(popup_header).append($("<h4>"+options.title+"</h4>")).append(popup_close);
    var popup_content = $("<div></div>", { class : "content" }).append(options.content);
    var popup_modal = $("<div></div>", { class : "uiBSgeneric_dialog_modal" , id:options.class});
    if(options.width!=false) $(popup_container).css({"width":options.width + 'px'});
    if(options.height!=false) $(popup_content).css({"max-height":options.height + 'px',"overflow":"auto"});
    if(options.start!=false) {
        var popup_form = $(options.start);
        $(popup_form).append(popup_title).append(popup_content).css({"margin":0});
        if(buts!=''){
            var popup_buttons = $("<div></div>", { class : "popup_buttons" }).html(buts);
            $(popup_form).append(popup_buttons);
        }
        $(popup_container).append(popup_form);
    } else {
        $(popup_container).append(popup_title).append(popup_content);
        if(buts!=''){
            var popup_buttons = $("<div></div>", { class : "popup_buttons" }).html(buts);
            $(popup_container).append(popup_buttons);
        }
    }
    $(popup_modal).append(popup_container);
    $("body").append(popup_modal);
    var top, left;
    top = Math.max($(window).height() - $(popup_container).outerHeight(), 0) / 2;
    left = Math.max($(window).width() - $(popup_container).outerWidth(), 0) / 2;
    if(options.positionTop > 0) {
        top += $(window).scrollTop();
    } else {
        top += options.positionTop;
    }
    $(popup_container).css({"top": top, "left": left + $(window).scrollLeft()});
    $(popup_close).click(function(){
        $("#"+options.class).remove();
        if(options.place){
            $("body").append(options.content);
            $(options.content).hide();
        }
    });
    $(".esc"+options.class).click(function(){ $(popup_close).click(); });
}

function filterInput(className){
	var success = true;
	$('.'+className).css({'border-color':'rgba(82, 168, 236, 0.8)', 'box-shadow':'0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(82, 168, 236, 0.6)', 'outline':'0 none'});
	$('.'+className).each(function(){
		$(this).val($.trim($(this).val()));
		if($.trim($(this).val()) == '') {
			$(this).css('border', 'solid thin red');
			success = (success)? $(this).focus(): '';
			success = false;
		}
	});
	return success;
}

jQuery(document).ready(function($) {

    (function() {

        var extend = {
                button      : '#back-top',
                text        : 'Back to Top',
                min         : 200,
                fadeIn      : 400,
                fadeOut     : 400,
                speed       : 800,
                easing      : 'easeOutQuint'
            },
            oldiOS     = false,
            oldAndroid = false;
        
        // Detect if older iOS device, which doesn't support fixed position
        if( /(iPhone|iPod|iPad)\sOS\s[0-4][_\d]+/i.test(navigator.userAgent) ) oldiOS = true;

        // Detect if older Android device, which doesn't support fixed position
        if( /Android\s+([0-2][\.\d]+)/i.test(navigator.userAgent) ) oldAndroid = true;

        $('body').append('<a href="#" id="' + extend.button.substring(1) + '" title="' + extend.text + '">' + extend.text + '</a>');
        $(extend.button).hide();
        $(window).scroll(function() {

            var pos = $(window).scrollTop();
        
            if( oldiOS || oldAndroid ) {
                $( extend.button ).css({
                    'position' : 'absolute',
                    'top'      : position + $(window).height()
                });
            }
        
            if (pos > extend.min) {
                $(extend.button).fadeIn(extend.fadeIn);
            } else {
                $(extend.button).fadeOut(extend.fadeOut);
            }
            
        });

        $(extend.button).click(function(e){
            $('html, body').animate({scrollTop : 0}, extend.speed, extend.easing);
            e.preventDefault();
        });

    })();

});