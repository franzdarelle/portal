<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <form method="post">
            <div id="login-box">
                <div id="login-title">PROFILE <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content">
                    <div class="login-box">
                        <div class="label-box">
                            <img src="<?php echo $baseURL ?>uploads/users/<?php echo @$image ?>" style="width:100px; height:100px">
                            <div style="margin-left:120px;margin-left: 120px;margin-top: -105px;line-height: 20px;font-weight: bold;font-size: 14px;">
                                <div><?php echo strtoupper(@$lname) ?></div> 
                                <div><?php echo @$fname ?></div>
                                <div><?php echo @$mname ?></div>
                            </div>
                            <div style="margin-left:120px;margin-left: 120px;line-height: 20px;">
                                <img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align: middle">
                                <span><?php echo @$bdate ?></span>
                            </div>
                            <div style="margin-left:120px;margin-left: 120px;line-height: 20px;">
                                <img src="<?php echo $baseURL ?>assets/img/mail.png" style="vertical-align: middle">
                                <i><?php echo @$email ?></i>
                            </div>
                        </div>
                    </div>
                    <div class="login-box">
                        <div class="label-box"><label>BIRTH PLACE</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$bplace ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>ADDRESS</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$address ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>AREA OF SPECIALIZATION</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$specialization ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>MAJOR / EDUCATIONAL QUALIFICATION</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$qualification ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>SUBJECTS TAUGHT <img src="<?php echo $baseURL ?>assets/img/pencil.png" id="subjects"></label></div>
                        <?php if(@$teach): foreach ($teach as $key => $subject): ?>
                        <div>
                            <input class="input-group subjects" type="text" readonly value="<?php echo $subject ?>">
                        </div>
                        <?php endforeach; endif ?>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>BS DEGREE/S</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$bsdeg ?>">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>MASTERS DEGREE/S</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$msdeg ?>">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>DOCTORATE DEGREE/S</label></div>
                        <div>
                            <input class="input-group" type="text" readonly value="<?php echo @$drdeg ?>">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="button" class="input-submit" value="Update">
                            <input type="button" class="input-cancel" value="Cancel" onclick="window.location='<?php print generateUrl("dashboard") ?>'">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div id="profiles">
    <div align="center">
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="bdate" value="<?php print @$bdate ?>" required id="datepicker">
                <input type="file" name="image" accept="image/*">
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="bplace" value="<?php print @$bplace ?>" placeholder="Birth Place" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="address" value="<?php print @$address ?>" placeholder="Address" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="specialization" value="<?php print @$specialization ?>" placeholder="Area of Specialization" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="qualification" value="<?php print @$qualification ?>" placeholder="Major/Educational Qualification" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="lname" value="<?php print @$lname ?>" placeholder="Last Name" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="fname" value="<?php print @$fname ?>" placeholder="First Name" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="mname" value="<?php print @$mname ?>" placeholder="Middle Name" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="email" name="email" value="<?php print @$email ?>" placeholder="Email" required>
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="bsdeg" value="<?php print @$bsdeg ?>" placeholder="BS Degree/s">
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="msdeg" value="<?php print @$msdeg ?>" placeholder="Masters Degree/s">
            </div>
        </div>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="drdeg" value="<?php print @$drdeg ?>" placeholder="Doctorate Degree/s">
            </div>
        </div>
    </div>
</div>
<div id="subjectsTaught">
    <div align="center">
        <?php if(@$teach): foreach ($teach as $key => $subject): ?>
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="teach[]" value="<?php print @$subject ?>" required>
                <?php if(!$key): ?>
                <img src="<?php echo $baseURL ?>assets/img/new.png" id="new">
                <?php else: ?>
                <img src="<?php echo $baseURL ?>assets/img/delete.png" class="del">
                <?php endif ?>                    
            </div>
        </div>
        <?php endforeach; else: ?> 
        <div class="label-box-10">
            <div>
                <input class="input-group" type="text" name="teach[]" required>
                <img src="<?php echo $baseURL ?>assets/img/new.png" id="new">
            </div>
        </div>
        <?php endif ?> 
    </div>
</div>
<link rel="stylesheet" href="<?php echo $baseURL ?>assets/jqueryui/jquery-ui.css">
<script src="<?php echo $baseURL ?>assets/jqueryui/jquery-ui.js"></script>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("dashboard") ?>'});
$(".del").click(function(){ $(this).parent("div").parent("div").remove() });
$("#subjectsTaught").hide();
$("#subjectsTaught").find('input').css({"width":320});
$("#subjectsTaught").find("div.label-box-10").find("div").css({"overflow":"hidden"});
$("#subjectsTaught").find("img#new").css({"vertical-align":"middle","cursor":"pointer"}).click(function(){ 
    var inp = $("<input>", {class:"input-group","type":"text","name":"teach[]"}).css({"width":320});
    var del = $("<img>", {"src":"<?php echo $baseURL ?>assets/img/delete.png"}).click(function(){
        $(this).parent("div").parent("div").remove();
    });
    var div = $("<div></div>").css({"overflow":"hidden"}).append(inp).append(del);
    var row = $("#subjectsTaught").find("div");
    $(row[0]).append($("<div></div>", {class:"label-box-10"}).append(div));
});
$("#datepicker").datepicker({changeYear:true,changeMonth:true});
$(".subjects").css({"margin-top":2});
$("#subjects").css({"vertical-align":"middle","cursor":"pointer"}).click(function(){
    popup_box({start:"<form method='post'></form>", title:"SUBJECTS TAUGHT", content:$("#subjectsTaught").show(), width:400, place:true, class:"dogz"}, {submit:true, name:"taught", id:"save", class:"input-submit", value:"Save"});
});
$("#profiles").hide().find('.label-box-10').each(function(){
    $(this).css({"padding":"10px 10px 0px","text-align":"left"});
});
$("#profiles").find('input.input-group').css({"padding":7});
$(".input-submit").click(function(){
    popup_box({start:"<form method='post' enctype='multipart/form-data'></form>", title:"UPDATE PROFILE", content:$("#profiles").show(), width:400, place:true, class:"bart"}, {submit:true, name:"update", id:"save", class:"input-submit", value:"Save", close:"Cancel"});
});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
},{close: "Close"});
<?php endif ?>
</script>