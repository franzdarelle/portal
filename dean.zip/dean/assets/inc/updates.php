<?php $baseURL = baseURL() ?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>'Guest','userimg'=>'avatar.png','current'=>getPageName(),'morecss'=>'whole nomarginright')) ?>
    <div align="center">
        <div id="login-box" class="whole">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align:bottom"> CCS UPDATES <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <?php $updates = $PORTAL->getUpdates() ?>
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>SUBJECT</th>
                            <th style="width:150px">POSTED BY</th>
                            <th style="width:150px">DATE POSTED</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        if($updates): 
                            foreach ($updates as $post): 
                                if(!$post['status']) continue;
                                $title = stripslashes($post['title']);
                    ?>
                        <tr>
                            <td><span class="popUp" title="<?php echo $title ?>" postID="<?php echo $post['id'] ?>"><?php echo (strlen($title)>70)? substr($title, 0, 70) . '...' : $title ?></span></td>
                            <td class="profilepop" userID="<?php echo $post['uid'] ?>"><?php echo stripslashes($post['lname'] . ', ' . $post['fname'] . ' ' . $post['mname'][0] . '.') ?></td>
                            <td><?php echo date("Y M d h:i A", strtotime($post['stamp'])) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php echo getContents("profilediv", array('baseURL'=>$baseURL)) ?>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">
    $(".close").css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("home") ?>' });
    $(".popUp").css({"cursor":"pointer"}).click(function(){ 
        var postID = $(this).attr('postID');
        $.ajax({
            url: "<?php print generateUrl('getUpdate') ?>",
            type:"POST",
            data:{id:postID}
        }).done(function(e){
            var content = $.parseJSON(e);
            popup_box({
                title: content['title'],
                content: "<div class='postUpdates'>" + content['content'] + "</div>", 
                class: "<?php print randomString() ?>", 
                positionTop : -10
            }, {close: "Close"});
        });
    });
</script>