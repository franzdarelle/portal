<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <form method="post" enctype="multipart/form-data">
            <div id="login-box">
                <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/pencil.png" style="vertical-align:bottom"> UPDATE FILE <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content">
                    <div class="login-box">
                        <div class="label-box"><label>Upload</label></div>
                        <div>
                            <input type="file" class="input-group" name="<?php print $HOLDER ?>[]" multiple="true">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Remove selected files</label></div>
                        <?php foreach (explode(", ", $file) as $key => $val): ?>
                        <div>
                            <input type="checkbox" name="remove[]" value="<?php print $key ?>"> <span class="folder"><a href="<?php print $baseURL . 'uploads/files/' . $uid . '/' . $val ?>" style="text-decoration:none; color:#888" target="_blank"><?php print $val ?></a></span>
                        </div>
                        <?php endforeach ?>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Public</label></div>
                        <div>
                            <input type="checkbox" name="public" value="1" <?php if(@$public): ?>checked="checked"<?php endif ?>> <span id="option">Make this file viewable and downloadable</span>
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Title</label></div>
                        <div>
                            <input type="text" class="input-group <?php echo $RANDOM ?>" name="title" value="<?php print @$title ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Description</label></div>
                        <div>
                            <textarea class="input-group <?php echo $RANDOM ?>" name="description"><?php print @$description ?></textarea>
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="submit" class="input-submit" value="Update" name="update" onclick="return filterInput('<?php echo $RANDOM ?>')">
                            <input type="button" class="input-cancel" value="Cancel" onclick="window.location='<?php print generateUrl("myfiles") ?>'">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("myfiles") ?>'});
$("textarea").css({"height":150});
$("span#option").css({"margin":"-2px 0 0 5px","position":"absolute"});
$("span.folder").css({"margin":"-2px 0 0 5px","position":"absolute"});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close: "Close"});
<?php endif ?>
</script>