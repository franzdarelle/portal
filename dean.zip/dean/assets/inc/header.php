<div id="topBar">
    <img src="<?php echo BASE_PATH ?>assets/img/lspu.png" id="L">
    <img src="<?php echo BASE_PATH ?>assets/img/ccs.png" id="R">
    <h1>COLLEGE OF COMPUTER STUDIES</h1>
    <h2>DEAN'S PORTAL</h2>
</div>

