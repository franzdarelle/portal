<div id="midBar">
    <div align="center">
        <form method="post">
            <div id="login-box">
                <div id="login-title">Sign In <img src="<?php echo baseURL() ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content">
                    <div class="login-box">
                        <div class="label-box"><label>Username</label></div>
                        <div>
                            <input class="input-group" name="username" type="text">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>Password</label></div>
                        <div>
                            <input class="input-group" name="password" type="password">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="submit" class="input-submit" name="loginBTN" value="Sign In" onclick="return filterInput('input-group')">
                            <input type="button" class="input-cancel" value="Cancel" onclick="window.location='<?php print generateUrl("home") ?>'">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("home") ?>'});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close : "Close"});
<?php endif ?>
</script>
