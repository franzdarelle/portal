<?php
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfiles();
    $uploads = $PORTAL->getUploads();
    $updates = $PORTAL->getUpdates();
    $faculty = $download = $ccsposts = [];
    if($profile) foreach ($profile as $prof) $faculty[] = $prof['image']; 
    if($uploads) foreach ($uploads as $file) if($file['public'] AND $file['publish']) $download[] = $file;
    if($updates) foreach ($updates as $post) if($post['status']) $ccsposts[] = $post;
?>
<div id="midBar">
    <div>
        <div class="span2">
            <div class="menu-box-menu" style="width:96%">
                <div class="menu-content" >
                    <img src="<?php echo $baseURL ?>assets/img/chat.png">
                    <span>DEAN'S MESSAGE</span>
                </div>
                <div class="count-content" id="deanMessage"><?php print stripslashes($PORTAL->getMessage(1)) ?></div>      
            </div>
            <?php
                $announcements = stripslashes($PORTAL->getMessage(2)); 
                if($announcements): 
            ?>
            <div class="menu-box-menu" style="width:96%">
                <div class="menu-content" >
                    <img src="<?php echo $baseURL ?>assets/img/speaker.png">
                    <span>ANNOUNCEMENTS</span>
                </div>
                <div class="count-content" id="deanUpdates"><?php print $announcements ?></div>      
            </div>
            <?php endif ?>
        </div>
        <div class="span2">
            <div class="menu-box-menu">
                <div class="menu-content" id="viewUpdates">
                    <img src="<?php echo $baseURL ?>assets/img/calendar.png">
                    <span>CCS UPDATES</span>
                </div>
                <div class="count-content" id="userUpdates">
                <?php
                    $count = 0;
                    $limit = 10; 
                    foreach ($ccsposts as $post):
                        if($count==$limit) break; else $count++; 
                ?>
                    <div>
                        <div class="updateContents">
                            <img src="<?php echo $baseURL ?>uploads/users/<?php echo $post['image'] ?>" class="post">
                            <div class="update-holder">
                                <div class="update-title"><?php echo stripslashes($post['title']) ?></div>
                                <div>
                                    <span class="update-name"><?php echo stripslashes($post['lname'] . ', ' . $post['fname'] . ' ' . $post['mname'][0] . '.') ?></span>
                                    <span class="update-date"><?php echo date("F j, Y h:i a", strtotime($post['stamp'])) ?></span>
                                </div>
                                <div class="update-content postUpdates"><?php echo str_replace("../", $baseURL, stripslashes($post['content'])) ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach ?>
                </div>      
            </div>
        </div>
    </div>
    <div>
        <div class="span3">
            <a href="<?php print generateUrl("faculty") ?>">
                <div class="menu-box-menu" style="width:96%">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/community.png">
                        <span>FACULTY</span>
                    </div>
                    <div class="count-content">
                        <img src="<?php echo $baseURL ?>uploads/users/<?php echo empty($faculty)? "avatar.png" : $faculty[0] ?>" style="width:235px; height:235px" id="profile">
                    </div>      
                </div>
            </a>
        </div>
        <div class="span3">
            <div class="menu-box-menu" style="width:96%">
                <div class="menu-content" id="viewDownloads">
                    <img src="<?php echo $baseURL ?>assets/img/outgoing.png">
                    <span>DOWNLOADS</span>
                </div>
                <div id="downloads">
                <?php
                    $count = 0;
                    $limit = 10; 
                    foreach ($download as $file):
                        if($count==$limit) break; 
                        else {
                            $title = stripslashes($file['title']);
                            $files = explode(", ", $file['file']);
                            $nfile = count($files);
                            if($nfile > 1) {
                                $isFolder = true; 
                                $fileIcon = $baseURL . 'assets/img/briefcase.png';
                            } else {
                                $isFolder = false;
                                $userFile = $baseURL . 'uploads/files/' . $file['uid'] . '/' . $file['file'];       
                                $fileIcon = getFileIcon($userFile);                      
                            }
                            $count++;
                        }
                ?>
                    <div>
                        <img src="<?php echo $fileIcon ?>">
                        <?php if($isFolder): ?>
                        <span class="download" fileID="<?php echo $file['id'] ?>" title="View <?php print $nfile . " files" ?>"><?php echo $title ?></span>
                        <?php else: ?>
                        <span><a href="<?php echo $userFile ?>" title="Download <?php echo $title ?>"><?php echo $title ?></a></span>
                        <?php endif ?>  
                    </div>
                <?php endforeach ?>
                </div>
            </div>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("create") ?>">
                <div class="menu-box-menu">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/pencil.png">
                        <span>CREATE ACCOUNT</span>
                    </div>
                </div>
            </a>
            <a href="<?php print generateUrl("signin") ?>">
                <div class="menu-box-menu">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/cog.png">
                        <span>SIGN IN</span>
                    </div>
                </div>
            </a>
            <div id="calendar" class="menu-box-menu"></div>
        </div>
    </div>
 </div>
<script type="text/javascript">
$(document).ready(function(){
    var faculty = <?php print json_encode($faculty) ?>;
    var current = 1;
    if(faculty.length > 1) {
        setInterval(function(){
            $("#profile").fadeOut("slow").attr("src", "<?php echo $baseURL ?>uploads/users/" + faculty[current]).fadeIn("slow");
            if(current==(faculty.length-1)) current = 0;
            else current++;
        }, 3000);
    }
    $('#calendar').css({"font" : "12px/18px Arial,sans-serif"}).fullCalendar({
        header: {
            left: 'prev,next',
            center: 'title',
            right: ''
        },
        editable: false
    });
    $(".download").css({"cursor":"pointer"}).click(function(){ 
        var fileID = $(this).attr('fileID');
        $.ajax({
            url: "<?php print generateUrl('getFiles') ?>",
            type:"POST",
            data:{id:fileID},
            dataType:"html"
        }).done(function(e){
            var obj = $.parseJSON(e);
            var box = $("<div></div>", {class:"login-box"});
            var zip = $("<div></div>").append('<img src="<?php echo $baseURL . "assets/img/extension/zip.png" ?>" class="icon">' + obj.title + '.zip').css({"cursor":"pointer"}).click(function(){
                $.ajax({
                    url: "<?php print generateUrl('downloadZip') ?>",
                    type:"POST",
                    data:{id:fileID}
                }).done(function(e){
                    var obj = $.parseJSON(e);
                    location.href = obj.zip;
                });
            });
            $.each(obj.files, function(key,val){
                var div = $("<div></div>");
                var fly = $("<a target='_blank'></a>").css({"text-decoration":"none","color":"#888"}).attr("href", val['file']);
                fly.append($("<img>", {class:"icon"}).attr("src", val['icon']));
                fly.append(val['name']);
                box.append(div.append(fly));
            });
            popup_box({
                title: obj.title,
                width: 300,
                content: box.append(zip),
                positionTop : -10
            }, {close: "Close"});
        });
    });
    $('.fc-content').click(function(){ window.location='<?php print generateUrl("calendar") ?>' });
    $('.update-content').last().css({"padding-bottom":0});
    $('#viewUpdates').css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("updates") ?>' });
    $('#viewDownloads').css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("downloads") ?>' });
});
</script>