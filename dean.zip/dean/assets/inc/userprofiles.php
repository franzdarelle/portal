<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <div id="login-box" class="whole">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/community.png" style="vertical-align:bottom"> FACULTY <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <div class="tableoptions">
                    <button class="input-submit tableactions deletebutton" input-class="xxx" ajax-path="<?php print generateUrl('deleteuser') ?>">Delete</button>
                </div>
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th class="checkAll"><input type="checkbox" name="checkall" input-class="xxx"/></th>
                            <th class="checkAll">Image</th>
                            <th>Full Name</th>
                            <th>Address</th>
                            <th>Email Address</th>
                            <th style="width:100px">Birth Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $profiles = $PORTAL->getProfiles();
                        if($profiles): 
                            foreach ($profiles as $prof):
                    ?>
                        <tr>
                            <td class="center"><input type="checkbox" value="<?php echo $prof['id'] ?>" class="xxx"/></td>
                            <td align="center"><img src="<?php echo $baseURL ?>uploads/users/<?php echo $prof['image'] ?>" class="profilepix"></td>
                            <td class="profilepop" userID="<?php echo $prof['uid'] ?>"><?php echo stripslashes($prof['lname'] . ', ' . $prof['fname'] . ' ' . $prof['mname']) ?></td>
                            <td><?php echo stripslashes($prof['address']) ?></td>
                            <td><a href="mailto:" style="text-decoration:none; color:#888"><?php echo stripslashes($prof['email']) ?></a></td>
                            <td><?php echo date("F j, Y", strtotime($prof['bdate'])) ?></td>
                        </tr>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php echo getContents("profilediv", array('baseURL'=>$baseURL)) ?>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">$(".close").css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("dashboard") ?>' })</script>