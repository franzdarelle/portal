<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
    $fileDIR = $baseURL . 'uploads/files/' . $uid . '/';
    $fileEXP = explode(", ", $file);
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <form method="post">
            <div id="login-box">
                <div id="login-title"><img src="<?php echo $baseURL . 'assets/img/chat.png' ?>" style="vertical-align:bottom"> REVIEW FILE <img src="<?php echo $baseURL . 'assets/img/delete.png' ?>" class="pull-right close"></div>
                <div id="login-content">
                    <div class="login-box">
                        <div class="label-box"><label><strong><?php echo stripslashes($title) ?></strong></label></div>
                        <div class="label-box"><label><i><?php echo stripslashes($description) ?></i></label></div>
                        <?php foreach ($fileEXP as $file): ?>
                        <div><a href="<?php echo $fileDIR . $file ?>" title="Download <?php echo $file ?>" style="text-decoration:none; color:#888" target="_blank"><img src="<?php echo getFileIcon($fileDIR . $file) ?>" class="icon"><?php echo $file ?></a></div>
                        <?php endforeach ?>
                        <?php if(count($fileEXP)>1): ?>
                        <div id="downloadZip"><img src="<?php echo $baseURL . 'assets/img/extension/zip.png' ?>" class="icon"><?php echo stripslashes($title) ?>.zip</div>
                        <?php endif ?>
                        <div><img src="<?php echo $baseURL ?>uploads/users/<?php echo $image ?>" class="icon"><?php echo stripslashes($lname . ', ' . $fname . ' ' . $mname[0] . '.') ?></div>
                        <div><img src="<?php echo $baseURL ?>assets/img/pencil.png" class="icon"><?php echo date("F j, Y h:i A", strtotime($stamp)) ?></div>
                    </div>
                    <div class="login-box">
                        <div class="label-box label-box-10"><label><strong>Comment:</strong></label></div>
                        <?php 
                            if($review): 
                                $comments = explode($binder, stripslashes($review));
                                foreach($comments as $comment):
                        ?>
                        <div>
                            <div class="comment"><?php echo $comment ?></div>
                        </div>
                        <?php endforeach; endif ?>
                        <div>
                            <textarea class="input-group" name="review"></textarea>
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="submit" class="input-submit" name="postBTN" value="Post Comment" onclick="return filterInput('input-group')">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
$("textarea").css({"height":100});
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("uploadedfiles") ?>'});
$(".comment").each(function(id){
    $(this).hover(
        function(){
            var button = $("<img>", {"src" : "<?php echo $baseURL ?>assets/img/delete.png"}).css({"top":5,"right":5,"position":"absolute"})
            .click(function(){
                if(confirm("Delete this comment?")) {
                    $.ajax({
                        url: "<?php print generateUrl('deleteReview') ?>",
                        type:"POST",
                        data:{key:id,val:<?php print $id ?>}
                    }).done(function(e){ 
                        $(location).attr("href", "<?php print generateUrl('reviewfile/' . $id) ?>");
                    });
                }
            });
            $(this).append(button);
        },
        function(){
            $(this).find('img').remove();
        }
    );
});
$("#downloadZip").css({"cursor":"pointer"}).click(function(){
    $.ajax({
        url: "<?php print generateUrl('downloadZip') ?>",
        type:"POST",
        data:{id:<?php print $id ?>}
    }).done(function(e){
        var obj = $.parseJSON(e);
        location.href = obj.zip;
    });
});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close : "Close"});
<?php endif ?>
</script>