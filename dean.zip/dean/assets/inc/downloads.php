<?php $baseURL = baseURL() ?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>'Guest','userimg'=>'avatar.png','current'=>getPageName(),'morecss'=>'whole nomarginright')) ?>
    <div align="center">
        <div id="login-box" class="whole">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/outgoing.png" style="vertical-align:bottom"> DOWNLOADS <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>TITLE</th>
                            <th>DESCRIPTION</th>
                            <th style="width:150px">UPLOADED BY</th>
                            <th style="width:150px">DATE MODIFIED</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $downloads = $PORTAL->getDownloads();
                        if($downloads): 
                            foreach ($downloads as $file): if(!$file['publish']) continue; 
                                $title = stripslashes($file['title']);
                                $files = explode(", ", $file['file']);
                                $nfile = count($files);
                                if($nfile > 1) {
                                    $isFolder = true; 
                                    $fileIcon = $baseURL . 'assets/img/briefcase.png';
                                } else {
                                    $isFolder = false;
                                    $userFile = $baseURL . 'uploads/files/' . $file['uid'] . '/' . $file['file'];       
                                    $fileIcon = getFileIcon($userFile);                      
                                }
                    ?>
                        <tr>
                            <td>
                                <?php if($isFolder): ?>
                                <span class="files" fileID="<?php echo $file['id'] ?>" title="View <?php print $nfile . " files" ?>"><img src="<?php echo $baseURL . "assets/img/download.png" ?>" class="icon"><?php echo $title ?></span>
                                <?php else: ?>
                                <span><a href="<?php echo $userFile ?>" title="Download <?php echo $title ?>" style="text-decoration:none; color:#888"><img src="<?php echo $baseURL . "assets/img/download.png" ?>" class="icon"><?php echo $title ?></a></span>
                                <?php endif ?>
                            </td>
                            <td><img src="<?php echo $fileIcon ?>" class="icon"><?php echo stripslashes($file['description']) ?></td>
                            <td class="profilepop" userID="<?php echo $file['uid'] ?>"><?php echo stripslashes($file['lname'] . ', ' . $file['fname'] . ' ' . $file['mname'][0] . '.') ?></td>
                            <td><?php echo strtoupper(date("Y M d h:i A", strtotime($file['stamp'])))?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php echo getContents("profilediv", array('baseURL'=>$baseURL)) ?>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("home") ?>'});
$(".files").css({"cursor":"pointer"}).click(function(){ 
    var fileID = $(this).attr('fileID');
    $.ajax({
        url: "<?php print generateUrl('getFiles') ?>",
        type:"POST",
        data:{id:fileID},
        dataType:"html"
    }).done(function(e){
        var obj = $.parseJSON(e);
        var box = $("<div></div>", {class:"login-box"});
        var zip = $("<div></div>").append('<img src="<?php echo $baseURL . "assets/img/extension/zip.png" ?>" class="icon">' + obj.title + '.zip').css({"cursor":"pointer"}).click(function(){
            $.ajax({
                url: "<?php print generateUrl('downloadZip') ?>",
                type:"POST",
                data:{id:fileID}
            }).done(function(e){
                var obj = $.parseJSON(e);
                location.href = obj.zip;
            });
        });
        $.each(obj.files, function(key,val){
            var div = $("<div></div>");
            var fly = $("<a target='_blank'></a>").css({"text-decoration":"none","color":"#888"}).attr("href", val['file']);
            fly.append($("<img>", {class:"icon"}).attr("src", val['icon']));
            fly.append(val['name']);
            box.append(div.append(fly));
        });
        popup_box({
            title: obj.title,
            width: 300,
            content: box.append(zip),
            positionTop : -10
        }, {close: "Close"});
    });
});
</script>