<?php $baseURL = baseURL() ?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>'Guest','userimg'=>'avatar.png','current'=>getPageName(),'morecss'=>'whole nomarginright')) ?>
    <div align="center">
        <div id="login-box">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align:bottom"> CALENDAR <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <div id="calendar"></div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('#login-box').css({"width":"100%"});
    $('#calendar').css({"font" : "12px/18px Arial,sans-serif"}).fullCalendar({
        header: {
            left: 'prev,next',
            center: 'title',
            right: ''
        },
        editable: false,
        events: [
        <?php 
            $events = $PORTAL->getEvents();
            if(!empty($events)):
            foreach($events as $e):
                $sdate = array(
                    date('Y', strtotime($e['sdate'])),
                    ((date('m', strtotime($e['sdate']))-1 > 0)? (date('m', strtotime($e['sdate']))-1) : 0),
                    date('d', strtotime($e['sdate']))
                );
                $edate = array(
                    date('Y', strtotime($e['edate'])),
                    ((date('m', strtotime($e['edate']))-1 > 0)? (date('m', strtotime($e['edate']))-1) : 0),
                    date('d', strtotime($e['edate']))
                );
        ?>
            {
                title:  "<?php print stripslashes($e['name']) ?>",
                start:  new Date(<?php print implode(",", $sdate) ?>),
                end:    new Date(<?php print implode(",", $edate) ?>),
                color:  '#4E69A2'
            }, 
        <?php endforeach; endif ?>
        ]
    });
    $(".close").css({"cursor":"pointer"}).click(function(){
        window.location='<?php print generateUrl("home") ?>';
    });
});
</script>