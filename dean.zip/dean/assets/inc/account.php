<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <form method="post">
            <div id="login-box">
                <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/cog.png" style="vertical-align:bottom"> ACCOUNT <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content">
                    <?php if($PORTAL->access->getType()): ?>
                    <div class="login-box">
                        <div class="label-box"><label>Security Code</label></div>
                        <div>
                            <input class="input-group" name="usercode" value="<?php print @$usercode ?>" readonly type="text">
                        </div>
                    </div>
                    <?php endif ?>
                    <div class="login-box">
                        <div class="label-box"><label>Username</label></div>
                        <div>
                            <input class="input-group" name="username" value="<?php print @$username ?>" readonly type="text">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>Password</label></div>
                        <div>
                            <input class="input-group" name="password" value="<?php print @$password ?>" readonly type="password">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div id="changeCode">
    <div align="center">
        <div class="label-box-10">
            <div class="label-box"><label>Password</label></div>
            <div>
                <input type="hidden" name="user" value="<?php print @$username ?>">
                <input class="input-group" name="pass" required type="password" value="<?php print @$pass ?>">
            </div>
        </div>
        <div class="label-box-10">
            <div class="label-box"><label>Security Code</label></div>
            <div>
                <input class="input-group" name="code" required type="text" value="<?php print @$code ?>">
            </div>
        </div>
    </div>
</div>
<div id="changeUser">
    <div align="center">
        <div class="label-box-10">
            <div class="label-box"><label>Password</label></div>
            <div>
                <input type="hidden" name="code" value="<?php print @$usercode ?>">
                <input class="input-group" name="pass" required type="password" value="<?php print @$pass ?>">
            </div>
        </div>
        <div class="label-box-10">
            <div class="label-box"><label>Username</label></div>
            <div>
                <input class="input-group" name="user" required type="text" value="<?php print @$user ?>">
            </div>
        </div>
    </div>
</div>
<div id="changePass">
    <div align="center">
        <div class="label-box-10">
            <div class="label-box"><label>Old Password</label></div>
            <div>
                <input class="input-group" name="opass" type="password" value="<?php print @$opass ?>" required>
            </div>
        </div>
        <div class="label-box-10">
            <div class="label-box"><label>New Password</label></div>
            <div>
                <input class="input-group" name="npass" type="password" value="<?php print @$npass ?>" required>
            </div>
        </div>
        <div class="label-box-10">
            <div class="label-box"><label>Confirm Password</label></div>
            <div>
                <input class="input-group" name="cpass" type="password" value="<?php print @$cpass ?>" required>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$("#changeCode, #changePass, #changeUser").hide().find('.label-box-10').each(function(){
    $(this).css({"padding":"10px","text-align":"left"});
});
$("input[name='usercode']").click(function(){
    popup_box({start:"<form method='post'></form>", title:"Security Code", content:$("#changeCode").show(), width:400, place:true, class:"eazy"}, {submit:true, name:"editCODE", id:"save", class:"input-submit", value:"Save", close:"Cancel"});
})
$("input[name='username']").click(function(){
    popup_box({start:"<form method='post'></form>", title:"Username", content:$("#changeUser").show(), width:400, place:true, class:"dogz"}, {submit:true, name:"editUSER", id:"save", class:"input-submit", value:"Save", close:"Cancel"});
})
$("input[name='password']").click(function(){
    popup_box({start:"<form method='post'></form>", title:"Password", content:$("#changePass").show(), width:400, place:true, class:"bart"}, {submit:true, name:"editPASS", id:"save", class:"input-submit", value:"Save", close:"Cancel"});
})
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("dashboard") ?>'});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close: "Close"});
<?php endif ?>
</script>