<div class="span12 noflow">
    <div class="menu-box-menu pull-right <?php print $morecss ?>">
        <div class="menu-content" id="breadcrumbs">
            <img src="<?php echo $baseURL . 'uploads/users/' . $userimg ?>">
            <span><?php print $userlog ?>  <img src="<?php echo $baseURL ?>assets/img/right.png"> <?php if(is_array($current)) print implode('<img src="'.$baseURL.'assets/img/right.png">', $current); else print $current; ?></span>
        </div>
    </div>
</div>