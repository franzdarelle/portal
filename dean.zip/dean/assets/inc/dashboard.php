<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'width97';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <?php if($PORTAL->access->getType()): ?>
    <div align="center">
    	<div class="span3">
            <a href="<?php print generateUrl("userprofiles") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/community.png">
                        <span>FACULTY</span>
                    </div>
                    <div class="count-content">Manage faculty</div>  
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("uploadedfiles") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/inbox.png">
                        <span>UPLOADS <span class="notif" id="uploadNotif"></span></span>
                    </div>
                    <div class="count-content">Manage user uploaded files</div> 
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("userupdates") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/calendar.png">
                        <span>UPDATES <span class="notif" id="updateNotif"></span></span>
                    </div>
                    <div class="count-content">Manage user updates</div> 
                </div>
            </a>
        </div>
    </div>
    <div align="center">
        <div class="span3">
            <a href="<?php print generateUrl("events") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/calendar.png">
                        <span>EVENTS</span>
                    </div>
                    <div class="count-content">Manage calendar of events</div> 
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("message") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/chat.png">
                        <span>MESSAGE</span>
                    </div>
                    <div class="count-content">Manage dean's message</div>  
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("announcement") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/speaker.png">
                        <span>ANNOUNCEMENTS</span>
                    </div>
                    <div class="count-content">Manage announcements</div>
                </div>
            </a>
        </div> 
    </div>
    <div align="center">
        <div class="span3">
            <a href="<?php print generateUrl("account") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/cog.png">
                        <span>ACCOUNT</span>
                    </div>
                    <div class="count-content">Manage account credentials</div>
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("logout") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/logoff.png">
                        <span>SIGN OUT</span>
                    </div>
                    <div class="count-content">End your session</div>
                </div>
            </a>
        </div>
        <div class="span3"></div>
    </div>
    <?php else: ?>
    <div align="center">
        <div class="span3">
            <a href="<?php print generateUrl("profile") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/pencil.png">
                        <span><?php echo strtoupper($userlog) ?></span>
                    </div>
                    <div class="count-content">Manage your profile information</div>
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("myfiles") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/inbox.png">
                        <span>UPLOADS</span>
                    </div>
                    <div class="count-content">Manage your uploaded files</div>
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("myupdates") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/calendar.png">
                        <span>UPDATES</span>
                    </div>
                    <div class="count-content">Manage your updates</div> 
                </div>
            </a>
        </div>
    </div>
    <div align="center">
        <div class="span3">
            <a href="<?php print generateUrl("account") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/cog.png">
                        <span>ACCOUNT</span>
                    </div>
                    <div class="count-content">Manage account credentials</div>
                </div>
            </a>
        </div>
        <div class="span3">
            <a href="<?php print generateUrl("logout") ?>">
                <div class="menu-box-menu width95">
                    <div class="menu-content">
                        <img src="<?php echo $baseURL ?>assets/img/logoff.png">
                        <span>SIGN OUT</span>
                    </div>
                    <div class="count-content">End your session</div>
                </div>
            </a>
        </div>
        <div class="span3"></div>
    </div>
    <?php endif ?>
</div>
<script type="text/javascript">
$(".notif").hide();
function setNotifs() {
    return $.ajax({
        url: "<?php print generateUrl('getNewUploadsAndUpdates') ?>",
        type:"POST",
        data:{id:1}
    }).done(function(e){
        var obj = $.parseJSON(e);
        if(obj['uploads'] > 0) $("#uploadNotif").text(obj['uploads']).fadeIn(); else $("#uploadNotif").fadeOut();
        if(obj['updates'] > 0) $("#updateNotif").text(obj['updates']).fadeIn(); else $("#updateNotif").fadeOut();
    });
}
function putNotifs() {
    setNotifs().done(function(){ setTimeout(putNotifs, 5000)});
}
putNotifs();
</script>