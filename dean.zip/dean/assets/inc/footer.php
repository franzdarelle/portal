<div id="botBar">
   <footer>LSPU CCS DEAN'S PORTAL &copy; 2015  |  <a href="mailto:" id="mailTo">lspu_ccs@gmail.com</a></footer>
</div>

