<div id="midBar">
    <div align="center">
        <form method="post">
            <div id="login-box">
                <div id="login-title">Create Account <img src="<?php echo baseURL() ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content">
                    <div class="login-box">
                        <div class="label-box"><label>Security Code</label></div>
                        <div>
                            <input class="input-group <?php print $RANDOM ?>" name="usercode" value="<?php print @$usercode ?>" type="text">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>Username</label></div>
                        <div>
                            <input class="input-group <?php print $RANDOM ?>" name="username" value="<?php print @$username ?>" type="text">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>Password</label></div>
                        <div>
                            <input class="input-group <?php print $RANDOM ?>" name="password" value="<?php print @$password ?>" type="password">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="label-box"><label>Confirm</label></div>
                        <div>
                            <input class="input-group <?php print $RANDOM ?>" name="pconfirm" value="<?php print @$pconfirm ?>" type="password">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="submit" class="input-submit" name="createBTN" value="Create" onclick="return filterInput('<?php print $RANDOM ?>')">
                            <input type="button" class="input-cancel" value="Cancel" onclick="window.location='<?php print generateUrl("home") ?>'">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("home") ?>'});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close : "Close"});
<?php endif ?>
</script>