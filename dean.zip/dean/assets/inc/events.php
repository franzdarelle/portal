<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <div id="login-box">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align:bottom"> EVENTS <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <div class="tableoptions">
                    <button class="input-submit tableactions addbutton" location="<?php print generateUrl('createEvent') ?>">+Create</button>
                    <button class="input-submit tableactions editbutton" input-class="xxx" location="<?php print generateUrl('updateEvent') ?>">Update</button>
                    <button class="input-submit tableactions deletebutton" input-class="xxx" ajax-path="<?php print generateUrl('deleteEvent') ?>">Delete</button>
                </div>
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th class="checkAll"><input type="checkbox" name="checkall" input-class="xxx"/></th>
                            <th>Name</th>
                            <th style="width:100px">Start Date</th>
                            <th style="width:100px">End Date</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $events = $PORTAL->getEvents();
                        if($events): 
                            foreach ($events as $event):
                    ?>
                        <tr>
                            <td class="center"><input type="checkbox" value="<?php echo $event['id'] ?>" class="xxx"/></td>
                            <td><?php echo stripslashes($event['name']) ?></td>
                            <td><?php echo date("F j, Y", strtotime($event['sdate'])) ?></td>
                            <td><?php echo date("F j, Y", strtotime($event['edate'])) ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">
$("#login-box").css({"width":"100%"});
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("dashboard") ?>'});
</script>