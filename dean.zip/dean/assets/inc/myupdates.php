<?php 
    $baseURL = baseURL();
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright'; 
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <div id="login-box">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align:bottom"> UPDATES <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <div class="tableoptions">
                    <button class="input-submit tableactions addbutton" location="<?php print generateUrl('postUpdate') ?>">+Create</button>
                    <button class="input-submit tableactions editbutton" input-class="xxx" location="<?php print generateUrl('editUpdate') ?>">Update</button>
                    <button class="input-submit tableactions deletebutton" input-class="xxx" ajax-path="<?php print generateUrl('deleteUpdate') ?>">Delete</button>
                </div>
                <?php $updates = $PORTAL->getUpdates($PORTAL->access->getUser()) ?>
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th class="checkAll"><input type="checkbox" name="checkall" input-class="xxx"/></th>
                            <th>Title</th>
                            <th style="width:130px">Date Posted</th>
                            <th style="width:130px">Date Modified</th>
                            <th style="width:30px">Publish</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        if($updates): 
                            foreach ($updates as $post):
                    ?>
                        <tr>
                            <td class="center"><input type="checkbox" value="<?php echo $post['id'] ?>" class="xxx"/></td>
                            <td><span class="popUp" postID="<?php echo $post['id'] ?>"><?php echo stripslashes($post['title']) ?></span></td>
                            <td><?php echo date("Y/m/d h:i A", strtotime($post['stamp'])) ?></td>
                            <td><?php echo date("Y/m/d h:i A", strtotime($post['date_modified'])) ?></td>
                            <td align="center"><?php if($post['status']): ?><img src="<?php echo $baseURL ?>assets/img/tick.png"><?php else: ?><img src="<?php echo $baseURL ?>assets/img/delete.png"><?php endif ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">
    $("#login-box").css({"width":"100%"});
    $(".close").css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("dashboard") ?>' });
    $(".popUp").css({"cursor":"pointer"}).click(function(){ 
        var postID = $(this).attr('postID');
        $.ajax({
            url: "<?php print generateUrl('getUpdate') ?>",
            type:"POST",
            data:{id:postID}
        }).done(function(e){
            var content = $.parseJSON(e);
            popup_box({
                title: content['title'],
                content: "<div class='postUpdates'>" + content['content'] + "</div>", 
                class: "<?php print randomString() ?>", 
                positionTop : -10
            }, {close: "Close"});
        });
    });
</script>