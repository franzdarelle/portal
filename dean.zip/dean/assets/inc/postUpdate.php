<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <form method="post">
            <div id="login-box" class="w430">
                <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align:bottom"> POST UPDATE <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content" class="pad15">
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Title</label></div>
                        <div>
                            <input type="text" class="input-group" name="title" value="<?php print @$title ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Content</label></div>
                        <div>
                            <textarea class="input-group" name="content"><?php print stripslashes(@$content) ?></textarea>
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="submit" class="input-submit" value="Create" name="create">
                            <input type="button" class="input-cancel" value="Cancel" onclick="window.location='<?php print generateUrl("myupdates") ?>'">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript">
tinymce.init({
    selector: "textarea[name='content']",
    plugins: [
        "advlist autolink lists charmap print preview anchor",
        "searchreplace visualblocks code fullscreen",
        "insertdatetime table contextmenu paste textcolor colorpicker image insertdatetime"
    ],
    toolbar: "insertfile undo redo | searchreplace bullist numlist outdent indent | blockquote charmap image |  fontselect fontsizeselect forecolor backcolor | insertdatetime"
});
$(".close").css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("myupdates") ?>' });
$("textarea").css({"height":150});
$(".input-group").css({"width":380});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close: "Close"});
<?php endif ?>
</script>