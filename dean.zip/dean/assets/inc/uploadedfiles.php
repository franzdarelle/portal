<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <div id="login-box" class="whole">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/inbox.png" style="vertical-align:bottom"> UPLOADS <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <div class="tableoptions">
                    <button class="input-submit tableactions editbutton" input-class="xxx" location="<?php print generateUrl('reviewfile') ?>">Review</button>
                    <button class="input-submit tableactions publishbutton" input-class="xxx" ajax-path="<?php print generateUrl('publishfile') ?>" location="<?php print generateUrl('uploadedfiles') ?>" question="Publish">Publish</button>
                    <button class="input-submit tableactions publishbutton" input-class="xxx" ajax-path="<?php print generateUrl('unpublishfile') ?>" location="<?php print generateUrl('uploadedfiles') ?>" question="Unpublish">Unpublish</button>
                    <button class="input-submit tableactions deletebutton" input-class="xxx" ajax-path="<?php print generateUrl('deletefile') ?>">Delete</button>
                </div>
                <?php $uploads = $PORTAL->getUploads() ?>
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th class="checkAll"><input type="checkbox" name="checkall" input-class="xxx"/></th>
                            <th>Title</th>
                            <th style="width:120px">Description</th>
                            <th style="width:120px">Uploaded By</th>
                            <th style="width:130px">Date Modified</th>
                            <th style="width:30px">Public</th>
                            <th style="width:30px">Publish</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        if($uploads): 
                            foreach ($uploads as $file): 
                                if($file['new']) $PORTAL->setUploadCategory(0, $file['id']);
                                $title = stripslashes($file['title']);
                                $files = explode(", ", $file['file']);
                                $nfile = count($files);
                                $icons = ($nfile > 1)? $baseURL . 'assets/img/briefcase.png' : getFileIcon($baseURL . 'uploads/files/' . $file['uid'] . '/' . $file['file']);
                    ?>
                        <tr>
                            <td class="center"><input type="checkbox" value="<?php echo $file['id'] ?>" class="xxx"/></td>
                            <td>
                                <?php if($file['review']): ?><img src="<?php echo $baseURL ?>assets/img/chat.png" class="icon popUp" fileID="<?php echo $file['id'] ?>"><?php endif ?>
                                <span class="goFly" id="<?php echo $file['id'] ?>" title="<?php print ($nfile > 1)? $nfile . ' files' : $title ?>"><?php echo $title ?></span>
                            </td>
                            <td><img src="<?php echo $icons ?>" class="icon"><?php echo stripslashes($file['description']) ?></td>
                            <td class="profilepop" userID="<?php echo $file['uid'] ?>"><?php echo stripslashes(implode(' ', array($file['fname'], $file['lname']))) ?></td>
                            <td><?php echo strtoupper(date("Y/m/d h:i A", strtotime($file['stamp'])))?></td>
                            <td align="center"><?php if($file['public']): ?><img src="<?php echo $baseURL ?>assets/img/tick.png"><?php else: ?><img src="<?php echo $baseURL ?>assets/img/delete.png"><?php endif ?></td>
                            <td align="center"><?php if($file['publish']): ?><img src="<?php echo $baseURL ?>assets/img/tick.png"><?php else: ?><img src="<?php echo $baseURL ?>assets/img/delete.png"><?php endif ?></td>
                        </tr>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php echo getContents("profilediv", array('baseURL'=>$baseURL)) ?>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("dashboard") ?>' });
$(".popUp").css({"cursor":"pointer"}).click(function(){ 
    var fileID = $(this).attr('fileID');
    $.ajax({
        url: "<?php print generateUrl('getFiles') ?>",
        type:"POST",
        data:{id:fileID},
        dataType:"html"
    }).done(function(e){
        var obj = $.parseJSON(e);
        var box = $("<div></div>");
        $.each(obj.views, function(key,val){
            box.append($("<div></div>", {class:"comment"}).html(val));
        });
        popup_box({
            title: '<img src="<?php echo $baseURL . "assets/img/chat.png" ?>" class="icon">' + ((obj.views.length>1)? "Comments" : "Comment"),
            content: box, 
            positionTop : -10
        }, {close: "Close"});
    });
});
$(".goFly").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("reviewfile") ?>/' + $(this).attr('id')});
</script>