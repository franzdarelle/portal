<div id="profilediv">
    <div id="login-box">
        <div id="login-content" style="padding:10px!important">
            <div class="login-box">
                <div class="label-box">
                    <img src="" style="width:100px; height:100px" id="image">
                    <div style="margin-left:120px;margin-left: 120px;margin-top: -105px;line-height: 20px;font-weight: bold;font-size: 14px;">
                        <div id="lname"></div> 
                        <div id="fname"></div>
                        <div id="mname"></div>
                    </div>
                    <div style="margin-left:120px;margin-left: 120px;line-height: 20px;">
                        <img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align: middle">
                        <span id="bdate"></span>
                    </div>
                    <div style="margin-left:120px;margin-left: 120px;line-height: 20px;">
                        <img src="<?php echo $baseURL ?>assets/img/mail.png" style="vertical-align: middle">
                        <i id="email"></i>
                    </div>
                </div>
            </div>
            <div class="login-box">
                <div class="label-box"><label>BIRTH PLACE:</label></div>
                <div id="bplace"></div>
            </div>
            <div class="login-box label-box-10">
                <div class="label-box"><label>ADDRESS:</label></div>
                <div id="address"></div>
            </div>
            <div class="login-box label-box-10">
                <div class="label-box"><label>AREA OF SPECIALIZATION:</label></div>
                <div id="specialization"></div>
            </div>
            <div class="login-box label-box-10">
                <div class="label-box"><label>MAJOR / EDUCATIONAL QUALIFICATION:</label></div>
                <div id="qualification"></div>
            </div>
            <div class="label-box-10">
                <div class="label-box"><label>BS DEGREE/S:</label></div>
                <div id="bsdeg"></div>
            </div>
            <div class="label-box-10">
                <div class="label-box"><label>MASTERS DEGREE/S:</label></div>
                <div id="msdeg"></div>
            </div>
            <div class="label-box-10">
                <div class="label-box"><label>DOCTORATE DEGREE/S:</label></div>
                <div id="drdeg"></div>
            </div>
            <div class="label-box-10">
                <div class="label-box"><label>SUBJECTS TAUGHT:</label></div>
                <div id="teach"></div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
$("label").css({"font-weight":"bold","font-size":12,"color":"#666"});
$(".profilepix").css({"width":50,"height":50});
$("#profilediv").hide();
$(".profilepop").css({"cursor":"pointer"}).click(function(){
    var userID = $(this).attr('userID');
    $.ajax({
        url: "<?php print generateUrl('getProfile') ?>",
        type:"POST",
        data:{id:userID}
    }).done(function(e){
        var obj = $.parseJSON(e);
        var div = $("#profilediv");
        div.find('#lname').html(obj['lname']);
        div.find('#fname').html(obj['fname']);
        div.find('#mname').html(obj['mname']);
        div.find('#bdate').html(obj['bdate']);
        div.find('#email').html(obj['email']);
        div.find('#image').attr('src', '<?php echo $baseURL ?>uploads/users/' + obj['image']);
        div.find('#bplace').html(obj['bplace']).css({"font-size":11});
        div.find('#address').html(obj['address']).css({"font-size":11});
        div.find('#specialization').html(obj['specialization']).css({"font-size":11});
        div.find('#qualification').html(obj['qualification']).css({"font-size":11});
        div.find('#bsdeg').html(obj['bsdeg']).css({"font-size":11});
        div.find('#msdeg').html(obj['msdeg']).css({"font-size":11});
        div.find('#drdeg').html(obj['drdeg']).css({"font-size":11});
        div.find('#teach').html(obj['teach']).css({"font-size":11});
        popup_box({
            title: "PROFILE",
            content: div.show(), 
            class: "<?php print randomString() ?>", 
            place: true,
            positionTop : 0
        }, {close: "Close"});
    });
});
</script>