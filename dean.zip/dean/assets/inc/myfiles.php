<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <div id="login-box" class="whole">
            <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/inbox.png" style="vertical-align:bottom"> UPLOADS <img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
            <div id="login-content">
                <div class="tableoptions">
                    <button class="input-submit tableactions addbutton" location="<?php print generateUrl('uploadfile') ?>">+Upload</button>
                    <button class="input-submit tableactions editbutton" input-class="xxx" location="<?php print generateUrl('updatefile') ?>">Update</button>
                    <button class="input-submit tableactions deletebutton" input-class="xxx" ajax-path="<?php print generateUrl('deletefile') ?>">Delete</button>
                </div>
                <table id="example" class="display stdtable" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th class="checkAll"><input type="checkbox" name="checkall" input-class="xxx"/></th>
                            <th>Title</th>
                            <th>Description</th>
                            <th style="width:130px">Date Modified</th>
                            <th style="width:30px">Public</th>
                            <th style="width:30px">Publish</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                        $uploads = $PORTAL->getUploads($PORTAL->access->getUser());
                        if($uploads): 
                            foreach ($uploads as $file):
                                $title = stripslashes($file['title']);
                                $files = explode(", ", $file['file']);
                                $nfile = count($files);
                                if($nfile > 1) {
                                    $isFolder = true; 
                                    $fileIcon = $baseURL . 'assets/img/briefcase.png';
                                } else {
                                    $isFolder = false;
                                    $userFile = $baseURL . 'uploads/files/' . $file['uid'] . '/' . $file['file'];       
                                    $fileIcon = getFileIcon($userFile);                      
                                }
                    ?>
                        <tr>
                            <td class="center"><input type="checkbox" value="<?php echo $file['id'] ?>" class="xxx"/></td>
                            <td>
                                <?php if($file['review']): ?><img src="<?php echo $baseURL . 'assets/img/chat.png' ?>" class="icon popUp" fileID="<?php echo $file['id'] ?>"><?php endif ?>
                                <?php if($isFolder): ?>
                                <span class="files" fileID="<?php echo $file['id'] ?>" title="View <?php print $nfile . " files" ?>"><?php echo $title ?></span>
                                <?php else: ?>
                                <a href="<?php echo $userFile ?>" title="Download <?php echo $title ?>" style="text-decoration:none; color:#888"><?php echo $title ?></a>
                                <?php endif ?>
                            </td>
                            <td><img src="<?php echo $fileIcon ?>" class="icon"><?php echo stripslashes($file['description']) ?></td>
                            <td><?php echo strtoupper(date("Y/m/d h:i A", strtotime($file['stamp'])))?></td>
                            <td align="center"><?php if($file['public']): ?><img src="<?php echo $baseURL ?>assets/img/tick.png"><?php else: ?><img src="<?php echo $baseURL ?>assets/img/delete.png"><?php endif ?></td>
                            <td align="center"><?php if($file['publish']): ?><img src="<?php echo $baseURL ?>assets/img/tick.png"><?php else: ?><img src="<?php echo $baseURL ?>assets/img/delete.png"><?php endif ?></td>
                        </tr>
                    <?php endforeach; endif ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<link rel="stylesheet" type="text/css" href="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/css/jquery.dataTables.css">
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.js"></script>
<script type="text/javascript" src="<?php echo $baseURL ?>assets/js/DataTables-1.10.4/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" class="init" src="<?php echo $baseURL ?>assets/js/table.js"></script>
<script type="text/javascript">
$(".close").css({"cursor":"pointer"}).click(function(){ window.location='<?php print generateUrl("dashboard") ?>' });
$(".popUp").css({"cursor":"pointer"}).click(function(){ 
    var fileID = $(this).attr('fileID');
    $.ajax({
        url: "<?php print generateUrl('getFiles') ?>",
        type:"POST",
        data:{id:fileID},
        dataType:"html"
    }).done(function(e){
        var obj = $.parseJSON(e);
        var box = $("<div></div>");
        $.each(obj.views, function(key,val){
            box.append($("<div></div>", {class:"comment"}).html(val));
        });
        popup_box({
            title: '<img src="<?php echo $baseURL . "assets/img/chat.png" ?>" class="icon">' + ((obj.views.length>1)? "Comments" : "Comment"),
            content: box, 
            positionTop : -10
        }, {close: "Close"});
    });
});
$(".files").css({"cursor":"pointer"}).click(function(){ 
    var fileID = $(this).attr('fileID');
    $.ajax({
        url: "<?php print generateUrl('getFiles') ?>",
        type:"POST",
        data:{id:fileID},
        dataType:"html"
    }).done(function(e){
        var obj = $.parseJSON(e);
        var box = $("<div></div>", {class:"login-box"});
        var zip = $("<div></div>").append('<img src="<?php echo $baseURL . "assets/img/extension/zip.png" ?>" class="icon">' + obj.title + '.zip').css({"cursor":"pointer"}).click(function(){
            $.ajax({
                url: "<?php print generateUrl('downloadZip') ?>",
                type:"POST",
                data:{id:fileID}
            }).done(function(e){
                var obj = $.parseJSON(e);
                location.href = obj.zip;
            });
        });
        $.each(obj.files, function(key,val){
            var div = $("<div></div>");
            var fly = $("<a target='_blank'></a>").css({"text-decoration":"none","color":"#888"}).attr("href", val['file']);
            fly.append($("<img>", {class:"icon"}).attr("src", val['icon']));
            fly.append(val['name']);
            box.append(div.append(fly));
        });
        popup_box({
            title: obj.title,
            width: 300,
            content: box.append(zip),
            positionTop : -10
        }, {close: "Close"});
    });
});
</script>