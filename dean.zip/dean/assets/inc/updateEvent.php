<?php 
    $baseURL = baseURL(); 
    $profile = $PORTAL->getProfile($PORTAL->access->getUser());
    $userlog = $profile? stripslashes($profile['fname'] . ' ' . $profile['lname']) : $PORTAL->access->getName(); 
    $userimg = $profile? $profile['image'] : "avatar.png";
    $current = getPageName();
    $morecss = 'whole nomarginright';
?>
<div id="midBar">
    <?php print getContents("breadcrumbs", array('baseURL'=>$baseURL,'userlog'=>$userlog,'userimg'=>$userimg,'current'=>$current,'morecss'=>$morecss)) ?>
    <div align="center">
        <form method="post">
            <div id="login-box">
                <div id="login-title"><img src="<?php echo $baseURL ?>assets/img/calendar.png" style="vertical-align:bottom"> UPDATE EVENT<img src="<?php echo $baseURL ?>assets/img/delete.png" class="pull-right close"></div>
                <div id="login-content">
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Name</label></div>
                        <div>
                            <input type="text" class="input-group" name="name" value="<?php print @$name ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>Start Date</label></div>
                        <div>
                            <input type="text" class="input-group" name="sdate" id="sdate" value="<?php print isset($sdate)? date('m/d/Y', strtotime($sdate)) : '' ?>">
                        </div>
                    </div>
                    <div class="login-box label-box-10">
                        <div class="label-box"><label>End Date</label></div>
                        <div>
                            <input type="text" class="input-group" name="edate" id="edate" value="<?php print isset($edate)? date('m/d/Y', strtotime($edate)) : '' ?>">
                        </div>
                    </div>
                    <div class="label-box-10">
                        <div class="pull-right">
                            <input type="submit" class="input-submit" value="Update" name="update" onclick="return filterInput('input-group')">
                            <input type="button" class="input-cancel" value="Cancel" onclick="window.location='<?php print generateUrl("events") ?>'">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<link rel="stylesheet" href="<?php echo $baseURL ?>assets/jqueryui/jquery-ui.css">
<script src="<?php echo $baseURL ?>assets/jqueryui/jquery-ui.js"></script>
<script type="text/javascript">
$("#edate").datepicker({changeYear:true,changeMonth:true,minDate:new Date($("#sdate").val())});
$("#sdate").datepicker({changeYear:true,changeMonth:true}).change(function(){
    var sdate = $(this).val();
    $("#edate").datepicker('destroy').datepicker({changeYear:true,changeMonth:true,minDate:new Date(sdate)});
    $("#edate").val(sdate);
});
$(".close").css({"cursor":"pointer"}).click(function(){window.location='<?php print generateUrl("events") ?>'});
<?php if($POPBOX): ?>
popup_box({
    content: "<?php print $POPBOX ?>", 
    class: "<?php print randomString() ?>", 
    positionTop : -10
}, {close : "Close"});
<?php endif ?>
</script>