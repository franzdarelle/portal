<?php 
class PORTAL extends TABLE {

	var $access,
        $upload,
		$shadow;

	function __construct() {
		parent::__construct();
		$this->access = new USER;
		$this->shadow = BASE_ROOT . '/assets/shw/';
        $this->upload = BASE_ROOT . '/uploads/files/';
    }

    public function escape($string) {
        $string = get_magic_quotes_gpc()? stripslashes($string) : $string;
        $string = addslashes($string);
        return $string;
    }

    public function signin($name, $pass, $type) {
        $this->setTable('user');
        $data = $this->select(array('*'), array(array('user','=', $name), array('user.id', '=', 'salt.id', true)), array('salt'));
        if($data) {
            $data = $data[0];
            $prefix = $data['prefix'];
            $suffix = $data['suffix'];
            $shadow = $prefix . $suffix . ".txt";
            $prefix = md5($prefix);
            $suffix = sha1($suffix);
            $rpword = sha1($pass);
            $rpword = md5($rpword);
            $rpword = base64_encode( $prefix.$rpword.$suffix );
            $rpword = md5($rpword);
            $rpword = sha1($rpword);
            $rpword = trim($rpword);
            $dbpass = trim($data['pass']);
            if($rpword==$dbpass AND $pass==$this->getContent($shadow)) {
                if($data['type']==$type) {
                    $this->access->setUser($data['id']);
                    $this->access->setName($data['user']);
                    $this->access->setType($data['type']);
                    return true;
                }
                    return false;
            }else
                return false;
        } else
            return false;
    }

    public function mkeShadow($file, $content){
        chmod($this->shadow, 0777);
        $fp = fopen($this->shadow.$file, 'w+') or die("mkeShadow()");
        if($fp){
            fwrite($fp, $content);
            fclose($fp);
        }
        chmod($this->shadow, 0600);
        return $this;
    }

    public function getShadow($id) {
        $this->setTable('salt');
        $data = $this->select(array('*'), array(array('id','=', $id)));
        return $data[0]['prefix'].$data[0]['suffix'];
    }

    public function remShadow($file){
        chmod($this->shadow, 0777);
        unlink($this->shadow.$file);
        chmod($this->shadow, 0600);
        return $this;
    }

    public function getContent($file){
        chmod($this->shadow, 0777);
        $content = trim(file_get_contents($this->shadow.$file));
        chmod($this->shadow, 0600);
        return $content;
    }

    public function changeUsername($name, $pass, $code=false) {
        if($pass==$this->getContent($this->getShadow($this->access->getUser()) . ".txt")) {
            if(strlen($name)<6) return "Username must be atleast 6 characters";
            if($code AND (strlen($code)<6)) return "Security code must be atleast 6 characters";
            $this->setTable('user');
            $this->id = $this->access->getUser();
            $this->user = $name;
            $this->code = $code? $code : '';
            $this->update();
            $this->access->setName($name);
            return true;
        }
        return "Invalid Password";
    }

    public function changePassword($opass, $npass, $cpass) {
        $i = $this->access->getUser();
        $p = $this->getContent($this->getShadow($i) . ".txt");
        if ($opass==$p) {
            if($npass==$cpass) {
                $newpass = $this->escape($npass);
                if(strlen($newpass)<6) return "Password must be atleast 6 characters";
                $prefix = randomString(10);
                $suffix = randomString(10);
                $newPrefix = $prefix;
                $newSuffix = $suffix;
                $prefix = md5($prefix);
                $suffix = sha1($suffix);
                $rpword = sha1($newpass);
                $rpword = md5($rpword);
                $rpword = base64_encode( $prefix.$rpword.$suffix );
                $rpword = md5($rpword);
                $rpword = sha1($rpword);
                $rpword = trim($rpword);

                $this->setTable('user');
                $this->id = $i;
                $this->pass = $rpword;
                $this->update();
                $this->remShadow($this->getShadow($i) . ".txt")->mkeShadow($newPrefix . $newSuffix . ".txt", $newpass);
                $this->pass = null;
                $this->setTable('salt');
                $this->id = $i;
                $this->prefix = $newPrefix;
                $this->suffix = $newSuffix;
                $this->update();
                return true;
            } else 
                return "Confirm New Password";
        } 
        return "Invalid Old Password";
    }

    public function getMessage($id) {
        $this->setTable('message');
        $data = $this->select(array('message'), array(array('id','=',$id)));
        return $data[0]['message'];
    }

    public function setMessage($message, $id) {
        $this->setTable('message');
        $this->id = $id;
        $this->message = $message;
        return $this->update();
    }

    public function getSecurityCode($id) {
        $this->setTable('user');
        $data = $this->select(array('code'), array(array('id','=',$id)));
        return $data[0]['code'];
    }

    public function inquireAccount($code, $name, $pass, $conf) {
        if($code==$this->getSecurityCode(1)) {
            if(strlen($name)<6) return "Username must be atleast 6 characters";
            if(strlen($pass)<6) return "Password must be atleast 6 characters";
            if($pass!=$conf) return "Please confirm your password";
            $this->setTable('user');
            $this->type = 0;
            $this->user = $name;

            $escape = $this->escape($pass);
            $prefix = randomString(10);
            $suffix = randomString(10);
            $newPrefix = $prefix;
            $newSuffix = $suffix;
            $prefix = md5($prefix);
            $suffix = sha1($suffix);
            $rpword = sha1($escape);
            $rpword = md5($rpword);
            $rpword = base64_encode( $prefix.$rpword.$suffix );
            $rpword = md5($rpword);
            $rpword = sha1($rpword);
            $rpword = trim($rpword);

            $this->pass = $rpword;
            $user = $this->create();
            $this->mkeShadow($newPrefix . $newSuffix . ".txt", $escape);

            $this->setTable('salt');
            $this->id = $user;
            $this->prefix = $newPrefix;
            $this->suffix = $newSuffix;
            $salt = $this->create();

            $this->createUploadFolder($user);
            return true;
        } else
            return "Invalid security code";
    }

    private function createUploadFolder($folder) { 
        return mkdir($this->upload . $folder, 0700);
    }

    public function getProfile($uid) {
        $this->setTable('profile');
        $data = $this->select(array('*'), array(array('uid','=',$uid)));
        return $data? $data[0] : [];
    }

    public function getProfiles() {
        $this->setTable('profile');
        return $this->select(array('*'));
    }

    public function saveProfile($image, $address, $bplace, $specialization, $qualification, $lname, $fname, $mname, $email, $bsdeg, $msdeg, $drdeg, $bdate, $uid, $id=null) {
        $this->setTable('profile');
        $this->uid = $uid;
        $this->image = $image;
        $this->address = $address;
        $this->bplace = $bplace;
        $this->specialization = $specialization;
        $this->qualification = $qualification;
        $this->lname = $lname;
        $this->fname = $fname;
        $this->mname = $mname;
        $this->email = $email;
        $this->bsdeg = $bsdeg;
        $this->msdeg = $msdeg;
        $this->drdeg = $drdeg;
        $this->bdate = $bdate;
        if($id) { 
            $this->id = $id;
            return $this->update();
        } else
            return $this->create();
    }

    public function deleteProfile($id) {
        $this->setTable('profile');
        $data = $this->select(array('uid','image'), array(array('id','=',$id)));
        $user = $data[0]['uid'];
        $path = str_replace("files", "users", $this->upload) . $data[0]['image'];

        $uploads = $this->getUploads($user);
        $updates = $this->getUpdates($user);
        if($uploads) foreach ($uploads as $file) $this->deleteUpload($file['id']);
        if($updates) foreach ($updates as $post) $this->deleteUpdate($post['id']);
        rmdir($this->upload . $user);
        
        $this->setTable('profile');
        $this->id = $id;
        if($this->delete()) {
            if(file_exists($path)) unlink($path);
            $this->remShadow($this->getShadow($user) . '.txt');
            $this->setTable('user');
            $this->id = $user;
            $this->delete();
            $this->setTable('salt');
            $this->id = $user;
            return $this->delete();
        }
    }

    public function setSubjects($teach, $id) {
       $this->setTable('profile'); 
       $this->id = $id;
       $this->teach = $teach;
       return $this->update();
    }

    public function saveFile($file, $title, $description, $public, $uid, $id=null) {
        $this->setTable('upload');
        $this->uid = $uid;
        $this->file = $file;
        $this->title = $title;
        $this->description = $description;
        $this->public = $public;
        if($id) { 
            $this->id = $id;
            return $this->update();
        } else
            return $this->create();
    }

    public function getUploads($uid=null) {
        $this->setTable('upload');
        $this->setOrder(array(array('stamp','DESC')));
        $where = $uid? array(array('upload.uid','=','profile.uid',true), array('upload.uid','=',$uid)) : array(array('upload.uid','=','profile.uid',true));
        $query = $this->select(array('upload.*','profile.lname','profile.fname','profile.mname'), $where, array('profile'));
        return $query;
    }

    public function getNewUploads() {
        $this->setTable('upload');
        $data = $this->select(array('COUNT(*) as notifs'), array(array('new', '=', 1)));
        return $data[0]['notifs'];
    }

    public function setUploadCategory($new, $id) {
        $this->setTable('upload');
        $this->id = $id;
        $this->new = $new;
        return $this->update();
    }

    public function getDownloads() {
        $this->setTable('upload');
        $this->setOrder(array(array('stamp','DESC')));
        $where = array(array('upload.uid','=','profile.uid',true), array('upload.public','=',1), array('upload.publish','=',1));
        $query = $this->select(array('upload.*','profile.lname','profile.fname','profile.mname'), $where, array('profile'));
        return $query;
    }

    public function getUpload($id) {
        $this->setTable('upload');
        $data = $this->select(array('upload.*','profile.lname','profile.fname','profile.mname','profile.image'), array(array('upload.uid','=','profile.uid',true), array('upload.id','=',$id)), array('profile'));
        return $data[0];
    }

    public function deleteUpload($id) {
        $upload = $this->getUpload($id);
        $files = explode(", ", $upload['file']);
        $paths = $this->upload . $upload['uid'] . '/';
        foreach ($files as $file) {
            if(file_exists($paths.$file)) unlink($paths.$file);
        }

        $this->setTable('upload');
        $this->id = $id;
        return $this->delete();
    }

    public function setFilePublish($id, $publish=0) {
        $this->setTable('upload');
        $this->id = $id;
        $this->publish = $publish;
        return $this->update();
    }

    public function addEvent($sdate, $edate, $name) {
        $this->setTable('event');
        $this->sdate = date("Y-m-d", strtotime($sdate));
        $this->edate = date("Y-m-d", strtotime($edate));
        $this->name = $name;
        return $this->create();
    }

    public function editEvent($sdate, $edate, $name, $id) {
        $this->setTable('event');
        $this->id = $id;
        $this->sdate = date("Y-m-d", strtotime($sdate));
        $this->edate = date("Y-m-d", strtotime($edate));
        $this->name = $name;
        return $this->update();
    }

    public function getEvent($id) {
        $this->setTable('event');
        $data = $this->select(array('*'), array(array('id','=', $id)));
        $data[0]['sdate'] = date("m/d/Y", strtotime($data[0]['sdate']));
        $data[0]['edate'] = date("m/d/Y", strtotime($data[0]['edate']));
        return $data[0];
    }

    public function deleteEvent($id) {
        $this->setTable('event');
        $this->id = $id;
        return $this->delete();
    }

    public function getEvents() {
        $this->setTable('event');
        $this->setOrder(array(array('sdate','DESC')));
        return $this->select(array('*'));
    }

    public function getUpdates($uid=null) {
        $this->setTable('post');
        $this->setOrder(array(array('post.date_modified','DESC'), array('post.stamp', 'DESC')));
        $where = $uid? array(array('post.uid','=','profile.uid',true), array('post.uid','=',$uid)) : array(array('post.uid','=','profile.uid',true));
        $query = $this->select(array('post.*','profile.lname','profile.fname','profile.mname','profile.image'), $where, array('profile'));
        return $query;
    }

    public function getNewUpdates() {
        $this->setTable('post');
        $data = $this->select(array('COUNT(*) as notifs'), array(array('new', '=', 1)));
        return $data[0]['notifs'];
    }

    public function setUpdateCategory($new, $id) {
        $this->setTable('post');
        $this->id = $id;
        $this->new = $new;
        return $this->update();
    }

    public function postUpdate($title, $content, $stamp, $uid) {
        $this->setTable('post');
        $this->uid = $uid;
        $this->stamp = $stamp;
        $this->title = $title;
        $this->content = $content;
        return $this->create();
    }

    public function editUpdate($title, $content, $id) {
        $this->setTable('post');
        $this->id = $id;
        $this->title = $title;
        $this->content = $content;
        return $this->update();
    }

    public function getUpdate($id) {
        $this->setTable('post');
        $data = $this->select(array('*'), array(array('id','=',$id)));
        return $data[0];
    }

    public function deleteUpdate($id) {
        $this->setTable('post');
        $this->id = $id;
        return $this->delete();
    }

    public function setUpdateStatus($id, $status=0) {
        $this->setTable('post');
        $this->id = $id;
        $this->status = $status;
        return $this->update();
    }

    public function setReview($review, $id) {
        $this->setTable('upload');
        $this->id = $id;
        $this->review = $review;
        return $this->update();
    }
}