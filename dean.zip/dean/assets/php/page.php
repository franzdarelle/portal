<?php
$CONTENT = array();
$REQUEST = trim(@$_GET['q']);

$ROUTER = new ROUTER;
$PARAMS = explode("/", $REQUEST);
if(count($PARAMS) > 1) {
	if((int)method_exists($ROUTER, $PARAMS[0]) AND is_callable(array($ROUTER, $PARAMS[0]))) {
		$METHOD = $PARAMS[0];
	}
} else
	$METHOD = empty($PARAMS[0])? 'home' : $PARAMS[0];

$CONTENT = $ROUTER->$METHOD($PARAMS);

function baseURL() {
	$currentFile = $_SERVER["PHP_SELF"];
	$urlParts = explode('/', $currentFile);
	unset($urlParts[count($urlParts) - 1]);
	return implode('/', $urlParts) . '/';
}

function getContents($file, $data=null) {
	$path = BASE_ROOT . "/assets/inc/" . $file .".php";
	if(file_exists($path)) {
		ob_start();
		if(!empty($data) AND is_array($data)) foreach ($data as $key => $val) $$key = $val;
		include $path;
		$contents = ob_get_contents();
		ob_end_clean();
		return $contents;
	}
}

function getArgument($argument=null) {
	$queue = isset($_GET['q']) ? $_GET['q'] : array();
	$args  = explode("/", $queue);
	$argument--;
	return isset($args[$argument])? $args[$argument] : null;
}

function generateUrl($method=null) {
    return baseURL() . $method;
}

function randomString($chars=5) {
	$string = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	$result = substr( str_shuffle( $string ), 0, $chars );
	return $result;
}

function getFileIcon($file) {
	$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
	$img = baseURL() . 'assets/img/extension/';
	switch ($ext) {
		case 'png':
		case 'jpg':
		case 'jpeg':
			$img .= 'jpg.png';
		break;
		case 'doc':
		case 'docx':
			$img .= 'doc.png';
		break;
		case 'xls':
		case 'xlsx':
			$img .= 'xls.png';
		break;
		case 'ppt':
		case 'pptx':
			$img .= 'ppt.png';
		break;
		case 'pdf':
			$img .= 'pdf.png';
		break;
		case 'psd':
			$img .= 'psd.png';
		break;
		case 'zip':
			$img .= 'zip.png';
		break;
		default:
			
		break;
	}
	return $img;
}

function getPageName() {
	$args = getArgument(1);
	$base = '<a href="'.generateUrl("dashboard").'">Dashboard</a>';
	$open = '<a href="'.generateUrl($args).'">';
	$halt = '</a>';
	switch ($args) {
		case 'dashboard':
			$page = $base;
		break;
		case 'myfiles':
		case 'uploadedfiles':
			$page = array($base, $open . 'Uploads' . $halt);
		break;
		case 'uploadfile':
			$page = array($base, '<a href="'.generateUrl("myfiles").'">Uploads</a>' , $open . 'Upload File' . $halt);
		break;
		case 'updatefile':
			$page = array($base, '<a href="'.generateUrl("myfiles").'">Uploads</a>' , '<a href="'.generateUrl($args . "/" . getArgument(2)).'">Update File</a>');
		break;
		case 'reviewfile':
			$page = array($base, '<a href="'.generateUrl("uploadedfiles").'">Uploads</a>' , '<a href="'.generateUrl($args . "/" . getArgument(2)).'">Review File</a>');
		break;
		case 'myupdates':
		case 'userupdates':
			$page = array($base, $open . 'Updates' . $halt);
		break;
		case 'postUpdate':
			$page = array($base, '<a href="'.generateUrl("myupdates").'">Updates</a>' , $open . 'Post Update' . $halt);
		break;
		case 'editUpdate':
			$page = array($base, '<a href="'.generateUrl("myupdates").'">Updates</a>' , '<a href="'.generateUrl($args . "/" . getArgument(2)).'">Edit Update</a>');
		break;
		case 'profile':
			$page = array($base, $open . 'Profile' . $halt);
		break;
		case 'account':
			$page = array($base, $open . 'Account' . $halt);
		break;
		case 'userprofiles':
			$page = array($base, $open . 'Faculty' . $halt);
		break;
		case 'events':
			$page = array($base, $open . 'Events' . $halt);
		break;
		case 'createEvent':
			$page = array($base, '<a href="'.generateUrl("events").'">Events</a>' , $open . 'Create Event' . $halt);
		break;
		case 'updateEvent':
			$page = array($base, '<a href="'.generateUrl("events").'">Events</a>' , '<a href="'.generateUrl($args . "/" . getArgument(2)).'">Update Event</a>');
		break;
		case 'message':
			$page = array($base, $open . 'Message' . $halt);
		break;
		case 'announcement':
			$page = array($base, $open . 'Announcement' . $halt);
		break;
		case 'faculty':
			$page = array('<a href="'.generateUrl().'">Home</a>', $open . 'Faculty' . $halt);
		break;
		case 'updates':
			$page = array('<a href="'.generateUrl().'">Home</a>', $open . 'Updates' . $halt);
		break;
		case 'downloads':
			$page = array('<a href="'.generateUrl().'">Home</a>', $open . 'Downloads' . $halt);
		break;
		case 'calendar':
			$page = array('<a href="'.generateUrl().'">Home</a>', $open . 'Calendar' . $halt);
		break;
		default:
			$page = '';
		break;
	}
	return $page;
}

function getFileName($path, $file) {
	if(file_exists($path . $file)) {
		$type = strtolower(pathinfo($file, PATHINFO_EXTENSION));
		$name = str_replace("." . $type, "", $file);
		$copy = 1;
		while(file_exists($path . $name . "(".$copy.")." . $type)) {
			$copy++;
		}
		$filename = $name . "(".$copy.")." . $type;
	} else
		$filename = $file;
	return $filename;
}

class ROUTER {

	var $PORTAL, $accept = array('png','jpg','jpeg','doc','docx','xls','xlsx','ppt','pptx','pdf','psd','zip');

	function __construct() { $this->PORTAL = new PORTAL; }

	public function logout() {
		session_destroy();
        clearstatcache();
		header("Location: " . generateUrl("home"));
	    exit;
	}

	public function home() {
		return array(
			'title' => "Home",
			'content' => getContents("home", ['PORTAL'=>$this->PORTAL])
		);
	}

	public function faculty() {
		return array(
			'title' => "Faculty",
			'content' => getContents("faculty", ['PORTAL'=>$this->PORTAL])
		);
	}

	public function downloads() {
		return array(
			'title' => "Downloads",
			'content' => getContents("downloads", ['PORTAL'=>$this->PORTAL])
		);
	}

	public function updates() {
		return array(
			'title' => "CCS Updates",
			'content' => getContents("updates", ['PORTAL'=>$this->PORTAL])
		);
	}

	public function calendar() {
		return array(
			'title' => "Calendar",
			'content' => getContents("calendar", ['PORTAL'=>$this->PORTAL])
		);
	}

	public function signin() {
		if($this->PORTAL->access->running()) {
			header("Location: " . generateUrl("dashboard"));
	    	exit;
		} else {
			if(isset($_SESSION['COMING'])) {
				$data['POPBOX'] = $_SESSION['COMING'];
				unset($_SESSION['COMING']);
			} else
				$data['POPBOX'] = false;
			
			$data['PORTAL'] = $this->PORTAL;
			if(isset($_POST['loginBTN'])) {
				$data = array_map("addslashes", $_POST);
				$args = getArgument(2);
				$type = ($args AND ($args=="admin"))? 1 : 0;
				if($this->PORTAL->signin($data['username'], $data['password'], $type)) {
					header("Location: " . generateUrl("dashboard"));
		    		exit;
				} else 
					$data['POPBOX'] = "Invalid username and/or password.";
			}
			return array(
				'title' => 'Sign In',
				'content' => getContents("signin", $data)
			);
		}
	}

	public function create() {
		$data['POPBOX'] = false;
		$data['RANDOM'] = randomString();
		if(isset($_POST['createBTN'])) {
			$data = array_merge($data, array_map("addslashes", $_POST));
			$inquire = $this->PORTAL->inquireAccount($data['usercode'], $data['username'], $data['password'], $data['pconfirm']);
			if($inquire===true) {
				$_SESSION['COMING'] = "Your account has been successfully created. You can sign in now using your account.";
				header("Location: " . generateUrl("signin"));
		    	exit;
			} else
				$data['POPBOX'] = $inquire;
		}
		return array(
			'title' => 'Create Account',
			'content' => getContents("create", $data)
		);
	}

	public function dashboard() {
		if($this->PORTAL->access->running()) {
			return array(
				'title' => "Dashboard",
				'content' => getContents("dashboard", ['PORTAL'=>$this->PORTAL] )
			);
		} else
			return $this->logout();
	}

	public function message() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			if(isset($_POST['postBTN'])) {
				$data['POPBOX'] = $this->PORTAL->setMessage(addslashes($_POST['message']), 1)? "Message successfully posted." : "Something went wrong...";
			}
			$data['message'] = stripslashes($this->PORTAL->getMessage(1));
			return array(
				'title' => "Message",
				'content' => getContents("message", $data)
			);
		} else
			return $this->logout();
	}

	public function announcement() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			if(isset($_POST['postBTN'])) {
				$data['POPBOX'] = $this->PORTAL->setMessage(addslashes($_POST['message']), 2)? "Announcement successfully posted." : "Something went wrong...";
			}
			$data['message'] = stripslashes($this->PORTAL->getMessage(2));
			return array(
				'title' => "Announcement",
				'content' => getContents("announcement", $data)
			);
		} else
			return $this->logout();
	}

	public function account() {
		if($this->PORTAL->access->running()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			if(isset($_POST['editPASS'])) {
				$data = array_merge($data, array_map("addslashes", $_POST));
				$save = $this->PORTAL->changePassword($data['opass'], $data['npass'], $data['cpass']);
				if($save===true) {
					unset($data['opass'], $data['npass'], $data['cpass']);
					$data['POPBOX'] = "Password successfully changed.";
				} else
					$data['POPBOX'] = $save;
			}
			if(isset($_POST['editUSER'])) {
				$data = array_merge($data, array_map("addslashes", $_POST));
				$save = $this->PORTAL->changeUsername($data['user'], $data['pass'], $data['code']);
				if($save===true) {
					unset($data['user'], $data['pass']);
					$data['POPBOX'] = "Username successfully changed.";
				} else
					$data['POPBOX'] = $save;
			}
			if(isset($_POST['editCODE'])) {
				$data = array_merge($data, array_map("addslashes", $_POST));
				$save = $this->PORTAL->changeUsername($data['user'], $data['pass'], $data['code']);
				if($save===true) {
					unset($data['code'], $data['pass']);
					$data['POPBOX'] = "Security code successfully changed.";
				} else
					$data['POPBOX'] = $save;
			}
			$data['username'] = $this->PORTAL->access->getName();
			$data['usercode'] = $this->PORTAL->getSecurityCode($this->PORTAL->access->getUser());
			$data['password'] = $this->PORTAL->getContent($this->PORTAL->getShadow($this->PORTAL->access->getUser()).'.txt');
			return array(
				'title' => "Account",
				'content' => getContents("account", $data)
			);
		} else
			return $this->logout();
	}

	public function profile() {
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			$data['PORTAL'] = $this->PORTAL;
			$data['POPBOX'] = false;
			$data['image'] = 'avatar.png';
			$data['lname'] = 'LAST NAME';
			$data['fname'] = 'First Name';
			$data['mname'] = 'Middle Name';
			$data['email'] = 'Email Address';

			$user = $this->PORTAL->getProfile($this->PORTAL->access->getUser());
			if(isset($_POST['update'])) {
				$file = Image::uploadFileImage('image', BASE_ROOT . '/uploads/users/', 100, 100);
				if(@$file['success']) $data['image'] = $file['success']['name'];
				else {
					$data['image'] = $user['image']? $user['image'] : $data['image'];
				}

				$data = array_merge($data, $_POST);
				$save = $this->PORTAL->saveProfile($data['image'], $data['address'], $data['bplace'], $data['specialization'], $data['qualification'], $data['lname'], $data['fname'], $data['mname'], $data['email'], $data['bsdeg'], $data['msdeg'], $data['drdeg'], date("Y-m-d", strtotime($data['bdate'])), $this->PORTAL->access->getUser(), @$user['id']);
				if($save) $data['POPBOX'] = "Profile successfully updated";
			}
			if(isset($_POST['taught']) AND isset($user['id'])) {
				$save = $this->PORTAL->setSubjects(implode(",", array_values($_POST['teach'])), $user['id']);
				if($save) $data['POPBOX'] = "Subject successfully updated";
			}

			$user = $this->PORTAL->getProfile($this->PORTAL->access->getUser());
			$user['bdate'] = isset($user['bdate'])? date("m/d/Y", strtotime($user['bdate'])) : date("m/d/Y");
			$user['teach'] = isset($user['teach'])? explode(",", $user['teach']) : [];
			return array(
				'title' => "Profile",
				'content' => getContents("profile", array_merge($data,$user))
			);
		} else
			return $this->logout();
	}

	public function getProfile() {
		$profile = $this->PORTAL->getProfile($_POST['id']);
		$profile['lname'] = strtoupper($profile['lname']);
		$profile['bdate'] = date("F j, Y", strtotime($profile['bdate']));
		$profile['teach'] = str_replace(",", ", ", $profile['teach']);
		exit(json_encode($profile));
	}

	public function getFiles() {
		$upload = $this->PORTAL->getUpload($_POST['id']);
		$folder = array();
		foreach (explode(", ", $upload['file']) as $file) {
			$userFile = BASE_ROOT . '/uploads/files/' . $upload['uid'] . '/' . $file;
			$filePath = baseURL() . '/uploads/files/' . $upload['uid'] . '/' . $file;
			$folder[] = array(
				'file' => $filePath,
				'icon' => getFileIcon($userFile),
				'name' => $file
			);
		}
		exit(json_encode(array('title'=>stripslashes($upload['title']),'files'=>$folder,'views'=>explode('-=-', stripslashes($upload['review'])))));
	}

	public function getUpdate() {
		$update = $this->PORTAL->getUpdate($_POST['id']);
		exit(json_encode(array_map("stripslashes", $update)));
	}

	public function myfiles() {
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			return array(
				'title' => "Uploads",
				'content' => getContents("myfiles", ['PORTAL'=>$this->PORTAL])
			);
		} else
			return $this->logout();
	}

	public function myupdates() {
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			return array(
				'title' => "Updates",
				'content' => getContents("myupdates", ['PORTAL'=>$this->PORTAL])
			);
		} else
			return $this->logout();
	}

	public function userprofiles() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			return array(
				'title' => "Faculty",
				'content' => getContents("userprofiles", ['PORTAL'=>$this->PORTAL])
			);
		} else
			return $this->logout();
	}

	public function uploadedfiles() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			return array(
				'title' => "Uploads",
				'content' => getContents("uploadedfiles", ['PORTAL'=>$this->PORTAL])
			);
		} else
			return $this->logout();
	}

	public function userupdates() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			return array(
				'title' => "Updates",
				'content' => getContents("userupdates", ['PORTAL'=>$this->PORTAL])
			);
		} else
			return $this->logout();
	}

	public function publishupdate() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['items'])) {
			$published = 0;
			foreach ($_POST['items'] as $key => $val) {
				if($this->PORTAL->setUpdateStatus($val, 1)) $published++;
			}
			return $published;
		}
	}

	public function unpublishupdate() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['items'])) {
			$published = 0;
			foreach ($_POST['items'] as $key => $val) {
				if($this->PORTAL->setUpdateStatus($val, 0)) $published++;
			}
			return $published;
		}
	}

	public function publishfile() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['items'])) {
			$published = 0;
			foreach ($_POST['items'] as $key => $val) {
				if($this->PORTAL->setFilePublish($val, 1)) $published++;
			}
			return $published;
		}
	}

	public function unpublishfile() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['items'])) {
			$published = 0;
			foreach ($_POST['items'] as $key => $val) {
				if($this->PORTAL->setFilePublish($val, 0)) $published++;
			}
			return $published;
		}
	}

	public function events() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			return array(
				'title' => "Events",
				'content' => getContents("events", ['PORTAL'=>$this->PORTAL])
			);
		} else
			return $this->logout();
	}

	public function uploadfile() {
		/* to adjust max upload filesize update "upload_max_filesize" in php.ini */
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			$data['FOLDER'] = BASE_ROOT . '/uploads/files/' . $this->PORTAL->access->getUser() . '/';
			$data['HOLDER'] = 'files';
			if(isset($_POST['upload'])) {
				$file = array();
				if(isset($_FILES[$data['HOLDER']])) {
					$files = $_FILES[$data['HOLDER']];
					foreach ($files['name'] as $dogz => $bart) {
						$type = strtolower(pathinfo($files['name'][$dogz], PATHINFO_EXTENSION));
						if(in_array($type, $this->accept)) {
							//$name = rand(12345678, 98765432) . '_' . rand(12345678, 98765432) . '.' . $type;
							$name = getFileName($data['FOLDER'], $files['name'][$dogz]);
							$move = move_uploaded_file($files['tmp_name'][$dogz], $data['FOLDER'] . $name);
							if($move) $file[] = $name;
						}
					}
				}

				$_POST['public'] = isset($_POST['public'])? $_POST['public'] : 0;
				$data = array_merge($data, $_POST);
				$save = $this->PORTAL->saveFile(implode(", ", $file), addslashes($data['title']), addslashes($data['description']), $data['public'], $this->PORTAL->access->getUser());
				if($save) {
					$uploaded = count($file);
					$data['POPBOX'] = $uploaded? (($uploaded>1)? $uploaded . " files" : "File") . " successfully uploaded" : "Something went wrong...";
				}
			}
			return array(
				'title' => "Upload File",
				'content' => getContents("uploadfile", $data)
			);
		} else
			return $this->logout();
	}

	public function updatefile() {
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			$data['RANDOM'] = randomString();
			$data['FILEID'] = getArgument(2);
			$data['FOLDER'] = BASE_ROOT . '/uploads/files/' . $this->PORTAL->access->getUser() . '/';
			$data['HOLDER'] = 'files';

			if(isset($_POST['update'])) {
				$upload = $this->PORTAL->getUpload($data['FILEID']);
				$absurd = explode(", ", $upload['file']);

				if(isset($_POST['remove'])) {
					foreach ($_POST['remove'] as $key) {
						$filename = $absurd[$key];
						unlink($data['FOLDER'] . $filename);
						unset($absurd[$key]);
					}
				}

				$file = array();
				if(isset($_FILES[$data['HOLDER']])) {
					$files = $_FILES[$data['HOLDER']];
					foreach ($files['name'] as $dogz => $bart) {
						$type = strtolower(pathinfo($files['name'][$dogz], PATHINFO_EXTENSION));
						if(in_array($type, $this->accept)) {
							//$name = rand(12345678, 98765432) . '_' . rand(12345678, 98765432) . '.' . $type;
							$name = getFileName($data['FOLDER'], $files['name'][$dogz]);
							$move = move_uploaded_file($files['tmp_name'][$dogz], $data['FOLDER'] . $name);
							if($move) $file[] = $name;
						}
					}
				}

				$_POST['public'] = isset($_POST['public'])? $_POST['public'] : 0;
				$data = array_merge($data, $_POST);
				$save = $this->PORTAL->saveFile(implode(", ", array_merge($file, $absurd)), addslashes($data['title']), addslashes($data['description']), $data['public'], $this->PORTAL->access->getUser(), $data['FILEID']);
				if($save) {
					$this->PORTAL->setUploadCategory(1, $data['FILEID']);
					$data['POPBOX'] = "File successfully updated";
				}
			}

			return array(
				'title' => "Update File",
				'content' => getContents("updatefile", array_merge($this->PORTAL->getUpload($data['FILEID']), $data))
			);
		} else
			return $this->logout();
	}

	public function deletefile() {
		if($this->PORTAL->access->running() AND isset($_POST['id'])) {
			exit($this->PORTAL->deleteUpload($_POST['id'])? true : false);
		}
	}

	public function reviewfile() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			$data['REVIEW'] = getArgument(2);
			$data['binder'] = "-=-";
			if(isset($_POST['postBTN'])) {
				$upload = $this->PORTAL->getUpload($data['REVIEW']);
				if($upload['review']) $review = explode($data['binder'], $upload['review']);
				$review[] = addslashes($_POST['review']);
				$data['POPBOX'] = $this->PORTAL->setReview(implode($data['binder'], $review), $data['REVIEW'])? "Comment successfully posted." : "Something went wrong...";
			}
			$file = $this->PORTAL->getUpload($data['REVIEW']);
			$data = array_merge($file, $data);
			return array(
				'title' => "Review File",
				'content' => getContents("reviewfile", $data)
			);
		} else
			return $this->logout();
	}

	public function deleteReview() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['key']) AND isset($_POST['val'])) {
			$binder = "-=-";
			$upload = $this->PORTAL->getUpload($_POST['val']);
			$review = explode($binder, $upload['review']);
			unset($review[$_POST['key']]);
			$review = count($review)? implode($binder, $review) : '';
			exit($this->PORTAL->setReview($review, $_POST['val'])? true : false);
		}
	}

	public function deleteUpdate() {
		if($this->PORTAL->access->running() AND isset($_POST['id'])) {
			exit($this->PORTAL->deleteUpdate($_POST['id'])? true : false);
		}
	}

	public function postUpdate() {
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			if(isset($_POST['create'])) {
				$data = array_merge($data, $_POST);
				$save = $this->PORTAL->postUpdate(addslashes($data['title']), addslashes($data['content']), date("Y-m-d H:i:s"), $this->PORTAL->access->getUser());
				if($save) $data['POPBOX'] = "Update successfully created";
			}
			return array(
				'title' => "Post Update",
				'content' => getContents("postUpdate", $data)
			);
		} else
			return $this->logout();
	}

	public function editUpdate() {
		if($this->PORTAL->access->running() AND !$this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			$data['UPDATE'] = getArgument(2);
			if(isset($_POST['update'])) {
				$data = array_merge($data, $_POST);
				$save = $this->PORTAL->editUpdate(addslashes($data['title']), addslashes($data['content']), $data['UPDATE']);
				if($save) {
					$this->PORTAL->setUpdateCategory(1, $data['UPDATE']);
					$data['POPBOX'] = "Update successfully updated";
				}
			}
			$post = $this->PORTAL->getUpdate($data['UPDATE']);
			$data = array_merge($post, $data);
			return array(
				'title' => "Edit Update",
				'content' => getContents("editUpdate", $data)
			);
		} else
			return $this->logout();
	}

	public function createEvent() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			if(isset($_POST['create'])) {
				$data = array_merge($data, $_POST);
				if(strtotime($data['sdate']) > strtotime($data['edate'])) {
					$edate = $data['edate'];
					$data['edate'] = $data['sdate'];
					$data['sdate'] = $edate;
				}
				$save = $this->PORTAL->addEvent($data['sdate'], $data['edate'], $data['name']);
				$data['POPBOX'] = $save? "Event successfully created." : "Something went wrong...";
			}
			return array(
				'title' => "Create Event",
				'content' => getContents("createEvent", $data)
			);
		} else
			return $this->logout();
	}

	public function updateEvent() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType()) {
			$data['POPBOX'] = false;
			$data['PORTAL'] = $this->PORTAL;
			$data['SEARCH'] = getArgument(2);
			if(isset($_POST['update'])) {
				$data = array_merge($data, $_POST);
				if(strtotime($data['sdate']) > strtotime($data['edate'])) {
					$edate = $data['edate'];
					$data['edate'] = $data['sdate'];
					$data['sdate'] = $edate;
				}
				$save = $this->PORTAL->editEvent($data['sdate'], $data['edate'], $data['name'], $data['SEARCH']);
				$data['POPBOX'] = $save? "Event successfully updated." : "Something went wrong...";
			}
			$data = array_merge($this->PORTAL->getEvent($data['SEARCH']), $data);
			return array(
				'title' => "Update Event",
				'content' => getContents("updateEvent", $data)
			);
		} else
			return $this->logout();
	}

	public function deleteEvent() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['id'])) {
			exit($this->PORTAL->deleteEvent($_POST['id'])? true : false);
		}
	}

	public function deleteuser() {
		if($this->PORTAL->access->running() AND $this->PORTAL->access->getType() AND isset($_POST['id'])) {
			exit($this->PORTAL->deleteProfile($_POST['id'])? true : false);
		}
	}

	public function downloadZip() {
		if(isset($_POST['id'])) {
			$upload = $this->PORTAL->getUpload($_POST['id']);
			$folder = BASE_ROOT . '/uploads/files/' . $upload['uid'] . '/';
			$zipdir = baseURL() . '/uploads/files/' . $upload['uid'] . '/';
			$newzip = stripslashes($upload['title']). '.zip';
			$zipper = $folder . $newzip;
			$opener = fopen($zipper, 'w')  or die("failed to execute downloadZip()");
			fclose($opener);

			$zip = new ZipArchive;
			if($zip->open($zipper) === TRUE) {
				foreach (explode(", ", $upload['file']) as $file) {
					$filename = $folder.$file;
					$zip->addFile($filename, $file);
				}
				$zip->close();
			}
			exit(json_encode(array('zip' => $zipdir . $newzip)));
		}
	}

	public function getNewUploadsAndUpdates() {
		if(isset($_POST['id'])) {
			exit(json_encode(array('updates'=> $this->PORTAL->getNewUpdates(), 'uploads'=> $this->PORTAL->getNewUploads())));
		}
	}
}

